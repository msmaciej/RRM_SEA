# PRESET_RRM_ORG Quality Hardening — Deliverables

This package ships the Phase A quality lift for `PRESET_RRM_ORG`, plus the
machinery to validate it numerically, compile-test each step, and tune it
without recompiling.

## File map

### Patches (apply to `RRM_SEA/`)
| File | What it is |
|---|---|
| `preset_rrm_org_PHASE_A.patch` | Unified diff against `SEA_Presets.mqh`. **Drop-in. No new struct fields, no new inputs.** |
| `SEA_Presets_PHASE_A.mqh` | Full pre-patched copy. Identical to original except for the `PRESET_RRM_ORG` block. |
| `preset_rrm_org_ORIGINAL.lf.mqh` / `preset_rrm_org_PHASE_A.lf.mqh` | Pristine + patched extracts of just the RRM_ORG block (LF line endings) for side-by-side review. |
| `PHASE_B_inputs_and_TE.mq5` | Phase B additions: ~25 new `Inp_RRM_ORG_*` operator inputs, three new `cfg.TE_*` struct fields, and the matching `EvaluateTE()` patch. Apply after Phase A is validated. |
| `PHASE_A1_reporting_extension.mq5` | OnDeinit reporting extension: per-gate rejection counters, the new "1b. PRE-FILTER QUALITY GATES" report section, and the new `PHASE_AGE` / `HTF_BLOCKED` pre-filters. Apply with Phase A. |

### Validation tooling
| File | What it is |
|---|---|
| `compile_check.sh` | Bash wrapper for `metaeditor64.exe` under macOS+Wine+MT5. Compiles the EA, parses the log, reports errors/warnings. Supports `--syntax-only`, `--step N` (per-step audit), `--diff-prev` (delta vs previous run), and `--strict`. |
| `analyze_phase_a_lift.py` | Stdlib-only Python analyzer. Two modes: single-CSV (per-gate predicted lift) and `--baseline-csv` (two-CSV comparison of pre-vs-post Phase A backtests). |

### Data
| File | What it is |
|---|---|
| `100-trades_labels.csv` | Ground-truth label template for the 100 reference trades. 16 rows pre-filled from the visual analysis. |
| `100-trades_labels.SYNTHETIC.csv` | Demonstration CSV with all 100 rows filled plausibly (random seed 42). **Synthetic — not for decisions.** |
| `100-trades_labels.SYNTHETIC.BASELINE.csv` | Synthetic pre-Phase-A baseline CSV (125 rows: SYNTHETIC + 25 extra losing trades). Pairs with the above for two-CSV demo. |
| `synthetic_demo_output.txt` | Captured single-CSV analyzer output. |
| `comparison_demo_output.txt` | Captured two-CSV comparison output. |

## Five-step rollout

### Step 1 — Apply Phase A
```bash
cd RRM_SEA
patch -p0 SEA_Presets.mqh < preset_rrm_org_PHASE_A.patch
```
Or copy the pre-patched file: `cp ../path/SEA_Presets_PHASE_A.mqh SEA_Presets.mqh`.

### Step 2 — Compile-test with `compile_check.sh`
```bash
./compile_check.sh --syntax-only          # fastest check, no .ex5 generated
```
On first run, the script auto-detects `metaeditor64.exe` from common Wine
paths. If detection fails, set:
```bash
export SEA_METAEDITOR="$HOME/.wine/drive_c/Program Files/MetaTrader 5/metaeditor64.exe"
export SEA_MQL5_DIR="$HOME/.wine/drive_c/users/$USER/AppData/Roaming/MetaQuotes/Terminal/<HASH>/MQL5"
```

Expected output on success:
```
─── compile_check.sh ──────────────────────────────────────────────
  metaeditor: /Users/.../metaeditor64.exe
  MQL5 dir:   /Users/.../MQL5
  EA file:    /Users/.../MQL5/Experts/RRMS/SimpleEA_v1-03.mq5
  log file:   /Users/.../.sea_compile_logs/compile_build_20260508_092301.log
  flags:      /compile:Z:\... /inc:Z:\... /log:Z:\... /s
───────────────────────────────────────────────────────────────────

Compile result:
  Errors:   0
  Warnings: 0

✓ Compile OK
```

### Step 3 — Apply Phase A.1 (per-gate reporting), one step at a time
Walk through `PHASE_A1_reporting_extension.mq5` step-by-step. After each
step, run:
```bash
./compile_check.sh --step 3 --diff-prev
```
The `--step` flag tags the log with the step number for audit. The
`--diff-prev` flag prints the warning-count delta vs the previous run, so
you immediately see if a step introduced new compiler warnings — even
if errors stay at zero.

### Step 4 — Run the labeled lift analysis
Fill in `100-trades_labels.csv` (outcomes + features), then:
```bash
python3 analyze_phase_a_lift.py 100-trades_labels.csv
```

### Step 5 — Run the two-CSV comparison after a real backtest
This is the strongest validation. Workflow:
1. Run a backtest on the **unpatched** repo. Export trades to `pre_phase_a.csv` matching the column schema of `100-trades_labels.csv`.
2. Apply Phase A. Run the **same backtest** (same period, symbols, settings) on the patched repo. Export to `post_phase_a.csv`.
3. Compare:
   ```bash
   python3 analyze_phase_a_lift.py --baseline-csv pre_phase_a.csv post_phase_a.csv
   ```

Expected output (from the synthetic demo):
```
========================================================================
COMPARISON MODE — pre-Phase-A vs post-Phase-A
========================================================================

1. TRADE-COUNT DELTA
   Baseline trades:                  41
   Phase A trades:                   16
   REMOVED by Phase A (good?):       25
   ADDED in Phase A only (?):         0

2. REMOVED-TRADE QUALITY (did Phase A kill losers?)
   Trades removed by Phase A:        25
   Winrate among REMOVED:           16.0%
   Baseline overall winrate:        47.9%
   Removed_WR − Baseline_WR:       -31.86%
     (LARGE NEGATIVE = Phase A correctly killed below-average trades ✓)
   Precision (frac of rejects = losers): 84.0%

3. SURVIVOR OUTCOME CONSISTENCY
   Surviving trades:                 16
   Same outcome in both runs:        16
   Different outcome:                 0

4. AGGREGATE METRICS
   metric          baseline  phase_a    delta
   Decided trades       117       92      -25
   Winrate            47.9%    56.5%   +8.66%
   Profit factor      +2.24    +3.14    +0.91
   Expectancy (R)   +0.52 R  +0.73 R  +0.21 R

5. VERDICT
   ✓ Phase A is removing trades with 16.0% winrate vs. baseline 47.9%
     overall — clear improvement on the rejection side.
   ✓ Aggregate winrate up +8.66%.
   ✓ Profit factor improved +2.24 → +3.14 (>10%).
```

The five-section structure tells you:
- **Section 1**: How many trades did Phase A remove? (Should not ADD any.)
- **Section 2**: Of the trades it removed, were they losers? (The headline metric.)
- **Section 3**: Of the trades that survived, did their outcomes change? (Should not — same setups, same SL/TP.)
- **Section 4**: Aggregate metric deltas with consistent presentation.
- **Section 5**: Auto-judged verdict with ✓ / ✗ / ◦ markers.

## A/B alternate threshold sets

Edit the constants at the top of `analyze_phase_a_lift.py`:
```python
EMA_FAN_MAX_PIPS = {
    "M1":  25.0, "M5":  25.0,
    "M15": 40.0, "M30": 40.0,
    ...
}
PHASE_AGE_MIN_BARS = {
    "M1":  1, "M5":  1,
    ...
}
```
Re-run. The script applies the new thresholds against the same labeled
outcomes — no MQL5 recompile needed. Once the optimum is found, encode
it as a Phase B input default.

## Apply order — quick reference

| When | What | Why |
|---|---|---|
| Day 1 | `patch < preset_rrm_org_PHASE_A.patch` | Activates the quality lift |
| Day 1 | `./compile_check.sh --syntax-only` | Confirms the patch compiles |
| Day 1 | Run baseline backtest, export → `pre.csv` | Pre-Phase-A reference |
| Day 1 | Apply Phase A.1 reporting | Lets you SEE which gate is doing what |
| Day 1 | `./compile_check.sh --step N --diff-prev` (×10) | Validate each A.1 step |
| Day 2 | Run Phase A backtest, export → `post.csv` | Post-Phase-A measurement |
| Day 2 | `python3 analyze_phase_a_lift.py --baseline-csv pre.csv post.csv` | The headline number |
| Day 3+ | Phase B inputs (optional) | Expose every gate as MT5 input |
| Day 5+ | Promote Phase A to default | After validation |

## What Phase A actually changes

All eleven changes are inside the `PRESET_RRM_ORG` block in
`SEA_Presets.mqh`; nothing else moves. Four themes:

**Activate dead-code filters (no behavior was on before):**
- `EmaFanFilterEnabled = true` with TF-scaled threshold (was `false`)
- `Ind_Dpi_Enabled = true` (was `false`, which silently disabled the
  already-coded `DpiDecelFilterEnabled` pre-filter)
- `UseHTF = true` with TF-scaled HTF period (was respecting input default `false`)
- `RRM_EnableDrawdownProtection = true` (was respecting input default)

**Stop the duplicate-write bug:**
- `RequireRecoveryMomentum` was set on line 1295 then unconditionally
  overwritten by line 1309. Patch removes the second write.

**Make existing knobs TF-aware:**
- `MinPhaseConfirmBars` — was 0 always, now 1/2/3 by TF.
- `EmaFanMaxTotalPips` — was 25 always, now scales 25 → 180 from M5 → D1.

**JPY-pair noise tolerance:**
- `Gate_Recovery.value` and `Gate_EmaDiv.value` scale to 1.3× on JPY pairs.

## Mapping changes to the 100-trades failure modes

| Failure mode | Example trades | Phase A change that addresses it |
|---|---|---|
| Pattern B — EM→TM flicker | #023, #030, #040, #070 | `MinPhaseConfirmBars` TF-scaled > 0; `RequireRecoveryMomentum` on intraday |
| Pattern C — Late-trend / overextended fan | #075, parts of #050, #080 | `EmaFanFilterEnabled = true`; `DpiDecelFilterEnabled` actually fires (DPI now on); `UseHTF` blocks counter-HTF entries |
| Pattern D — Tangled-ribbon false TM | #095 | `MinPhaseConfirmBars` rejects single-bar TM flickers |
| Pattern A winners (clean TM) | #001, #020, #044, #060, #089, #100 | Untouched — pass every new filter cleanly per design |
