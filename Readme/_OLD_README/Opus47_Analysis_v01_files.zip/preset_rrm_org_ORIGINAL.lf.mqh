   if(preset == PRESET_RRM_ORG)
   {
      // ================================================================
      // PRESET_RRM_ORG: Original Russ Horn RRM with Inline DPI Voter
      // ================================================================
      //
      // SIGNAL FORMULA (all steps must pass):
      //   STEP 1: DPI (inline MACD) — momentum direction voter
      //   STEP 2: Phase (4-EMA) — UNORDERED blocked, EMERGING/TRENDING allowed
      //   STEP 3: Layer (EMA pair spacing) — WEAK/MEDIUM/STRONG
      //   STEP 4: Recovery gates — Gate_Recovery + Gate_EmaDiv
      //   STEP 5: Bar close (BC_LAYER_AWARE) — close vs role-based EMA
      //   STEP 6: PSAR + CandleBody confirmation
      //   → ENTRY SIGNAL
      //
      // LOCKED: DPI (inline MACD), PSAR, CandleBody, phase structure,
      //         recovery gates, bar close mode.
      // FLEXIBLE: MACD periods (via Zone 3D inputs), SL/TP/Trail modes.
      // ================================================================

      // ── SIGNAL ARCHITECTURE: locked ──────────────────────────────────
      cfg.BiasMode               = BIAS_4EMA;
      cfg.AutoStrat              = STRAT_4EMA_LAYER;
      cfg.BiasFastID             = (int)ROLE_EMA3;    // EMA34: phase direction fast
      cfg.BiasSlowID             = (int)ROLE_EMA4;    // EMA89: phase direction slow
      cfg.MaType                 = METHOD_EMA;
      cfg.CloseOnReverse         = false;
      cfg.BiasEnabled            = true;
      cfg.RequirePriceCross      = false;
      cfg.MABenchmarkStrict      = false;
      cfg.UseMACompatSizer       = false;
      cfg.VoteMode               = VOTE_MODE_ALL;

      // ── EMA PERIODS: locked to RRM standard ──────────────────────────
      cfg.P_Ema1                 = 5;
      cfg.P_Ema2                 = 13;
      cfg.P_Ema3                 = 34;
      cfg.P_Ema4                 = 89;

      // ── DPI v31: opt-in voting indicator (user enables via Inp_Ind_Dpi_Enabled) ──
      cfg.Ind_Dpi_Enabled          = false;          // opt-in; user enables via Inp_Ind_Dpi_Enabled
      cfg.Ind_Dpi_Weight           = 1;
      cfg.DPI_MACD_Fast            = Inp_RRM_ORG_MACD_Fast;              // default 8
      cfg.DPI_MACD_Slow            = Inp_RRM_ORG_MACD_Slow;              // default 13
      cfg.DPI_RedSignalType        = Inp_RRM_ORG_DPI_RedSignalType;      // default 3 (EMA13)
      cfg.DPI_RedEMA_A             = Inp_RRM_ORG_DPI_RedEMA_A;           // default 5
      cfg.DPI_RedEMA_B             = Inp_RRM_ORG_DPI_RedEMA_B;           // default 8
      cfg.DPI_RedEMA_C             = Inp_RRM_ORG_DPI_RedEMA_C;           // default 13
      cfg.DPI_RedEMA_D             = Inp_RRM_ORG_DPI_RedEMA_D;           // default 21
      cfg.DPI_DoubleSmoothFirst    = Inp_RRM_ORG_DPI_DoubleSmoothFirst;  // default 5
      cfg.DPI_DoubleSmoothSecond   = Inp_RRM_ORG_DPI_DoubleSmoothSecond; // default 8
      cfg.DPI_UseCCIReset          = Inp_RRM_ORG_DPI_UseCCIReset;        // default true
      cfg.DPI_CCI_Period           = Inp_RRM_ORG_DPI_CCI_Period;         // default 13
      cfg.DPI_CCI_AppliedPrice     = (int)Inp_RRM_ORG_DPI_CCI_Price;     // default PRICE_TYPICAL
      cfg.DPI_UseGreenHist         = Inp_RRM_ORG_DPI_UseGreenHist;       // default true

      // ── PSAR: LOCKED ON (timing/direction confirmation) ───────────────
      cfg.Ind_Psar_Enabled       = true;
      cfg.P_PsarStep             = 0.05;
      cfg.P_PsarMax              = 0.5;
      cfg.Vote_AllowPsarFlip     = true;
      cfg.Vote_PsarFlipDelay     = -1;   // Persistent: evaluate dot position on every bar

      // ── CANDLE BODY ───────────────────────────────────────────────────
      cfg.Ind_CandleBody_Enabled      = Inp_Ind_CandleBody_Enabled;
      cfg.Ind_CandleBody_Weight       = 1;
      cfg.CandleBody_AvgPeriod        = Inp_Ind_CandleBody_AvgPeriod;
      cfg.CandleBody_MaxMult          = Inp_Ind_CandleBody_MaxMult;
      cfg.CandleBody_CheckBars        = Inp_Ind_CandleBody_CheckBars;
      // cfg.CandleBody_CheckBars   = (_Period <= PERIOD_M5) ? 3 : 5;
      cfg.CandleBody_RequireDirection = Inp_Ind_CandleBody_RequireDirection;
      
      // ── ALL OTHER INDICATORS: LOCKED OFF ─────────────────────────────
      cfg.Ind_Adx_Enabled        = false;
      cfg.Ind_Atr_Enabled        = false;
      cfg.Ind_Bb_Enabled         = false;
      cfg.Ind_CI_Enabled         = false;
      cfg.Ind_VRC_Enabled        = false;
      cfg.Ind_Cci_Enabled        = false;
      cfg.Ind_Macd_Enabled       = false;
      cfg.Ind_Mfi_Enabled        = false;
      cfg.Ind_P123_Enabled       = false;
      cfg.Ind_Ross_Enabled       = false;
      cfg.Ind_Rsi_Enabled        = false;
      cfg.Ind_Sto_Enabled        = false;
      cfg.Ind_SmaConverge_Enabled = false;
      cfg.Ind_SmaConverge_Weight  = 1;

      // ── ADX SETTINGS: safe defaults (disabled) ────────────────────────
      cfg.P_Adx                  = 14;
      cfg.T_Adx                  = 20.0;
      cfg.ADX_Mode               = ADX_MODE_STATIC;
      cfg.ADX_Percentile         = 50.0;
      cfg.ADX_Lookback           = 100;
      cfg.ADX_Threshold_Accumulation  = 12.0;
      cfg.ADX_Threshold_Trending      = 25.0;
      cfg.ADX_Threshold_Distribution  = 18.0;

      // ── ATR SETTINGS: safe defaults (disabled) ────────────────────────
      cfg.P_Atr                  = 14;
      cfg.ATR_VoteMinPips        = 5.0;
      cfg.ATR_VoteMaxPips        = 50.0;

      // ── MACD SETTINGS: safe defaults (disabled) ───────────────────────
      cfg.P_MacdFast             = 8;  // 12
      cfg.P_MacdSlow             = 13; // 26
      cfg.P_MacdSig              = 5;  //  9
      cfg.MacdVoteMode           = MACD_HISTOGRAM;
      cfg.MacdRequireSlope       = false;
      cfg.MacdRequireDivergence  = false;
      cfg.MacdRequireHook        = false;
      cfg.MacdFreshBars          = 3;
      cfg.MacdSlopeMin           = 0.00001;

      // ── CCI/RSI/STOCH/BB/MFI: safe defaults (all disabled) ───────────
      cfg.P_Cci                  = 14;
      cfg.CciMode                = CCI_TREND_ZERO;
      cfg.P_Rsi                  = 14;
      cfg.T_RsiOB                = 70.0;
      cfg.T_RsiOS                = 30.0;
      cfg.RsiMode                = RSI_TREND_ABOVE_50;
      cfg.P_StoK                 = 5;
      cfg.P_StoD                 = 3;
      cfg.P_StoSlow              = 3;
      cfg.T_StoOB                = 80.0;
      cfg.T_StoOS                = 20.0;
      cfg.StoMode                = STO_CROSS_SIGNAL;
      cfg.P_Bb                   = 20;
      cfg.P_BbDev                = 2.0;
      cfg.BbMode                 = BB_TREND_FOLLOW;
      cfg.P_Mfi                  = 14;
      cfg.T_MfiOB                = 80.0;
      cfg.T_MfiOS                = 20.0;
      cfg.MfiMode                = MFI_ZONE_FILTER;

      // ── CI/VRC: safe defaults (disabled) ─────────────────────────────
      cfg.CI_Period              = 14;
      cfg.CI_RangingThreshold    = 61.8;
      cfg.Ind_CI_Weight          = 1;
      cfg.VRC_ATR_Period         = 14;
      cfg.VRC_Lookback           = 100;
      cfg.VRC_LowThreshold       = 33.0;
      cfg.Ind_VRC_Weight         = 1;

      // ── BAR CLOSE (bcX): LOCKED to layer-aware ───────────────────────
      cfg.BarClose_Enabled       = true;
      cfg.BarClose_Mode          = BC_LAYER_AWARE;   // bcW=EMA1, bcM=EMA2, bcS=EMA3
      cfg.BarClose_DefaultEMA    = ROLE_EMA1;

      // ── PHASE DETECTION & LAYER FILTERING: LOCKED ON ─────────────────
      cfg.PhaseDetectionEnabled     = true;
      cfg.EnableLayerDetection      = true;
      cfg.BlockUnorderedPhase       = true;           // UNORDERED → block all trades
      cfg.BlockEmergingPhase        = true;           // true: EM phase = no trades; TM phase = trades allowed
      cfg.RequireRecoveryMomentum = (_Period <= PERIOD_M5) ? true : false; 
      cfg.MinPhaseConfirmBars     = (_Period <= PERIOD_M5) ? 0 : 0;        // M1: No delay needed on M1

      // EMERGING phase: WEAK + MEDIUM only; STRONG always blocked per RRM methodology
      cfg.Emerging_AllowWeakTrades   = Inp_RRM_AllowWeak;
      cfg.Emerging_AllowMediumTrades = Inp_RRM_AllowMedium;
      cfg.Emerging_AllowStrongTrades = false;         // STRONG always blocked in EMERGING per RRM methodology

      // TRENDING phase: controlled by layer filter inputs (Inp_RRM_Allow*)
      cfg.Trending_AllowWeakTrades   = Inp_RRM_AllowWeak;
      cfg.Trending_AllowMediumTrades = Inp_RRM_AllowMedium;
      cfg.Trending_AllowStrongTrades = Inp_RRM_AllowStrong;

      // ── PULLBACK DETECTION GATES: LOCKED ON ──────────────────────────
      cfg.RequireRecoveryMomentum   = false;   // Wick-touch recovery valid on M1/M5
      cfg.Gate_Recovery.mode        = GATE_SCALE_AUTO_TF;
      cfg.Gate_Recovery.value       = 1.0;
      cfg.RRM_Lookback              = (_Period <= PERIOD_M1) ? 15 : (_Period <= PERIOD_M5) ? 10 : 12;

      cfg.Gate_EmaDiv.mode          = GATE_SCALE_AUTO_TF;
      cfg.Gate_EmaDiv.value         = 1.0;
      cfg.RRM_MinDivPips            = 1.5;

      cfg.Gate_CandleDirection.mode  = GATE_SCALE_FIXED;
      cfg.Gate_CandleDirection.value = 1.0;

      // ── VOTE EVALUATION ───────────────────────────────────────────────
      cfg.Vote_EvalShift            = 1;

      // ── RISK MANAGEMENT ───────────────────────────────────────────────
      cfg.CountBEasZeroRisk         = true;
      cfg.FixedLotSize              = 0.0;

      // ── EXIT STRATEGY: flexible (uses RRM profile, SL/TP from inputs) ─
      cfg.ExitProfile               = EXIT_PROFILE_RRM;
      cfg.SLMode                    = Inp_RRM_SLMode;
      cfg.TPMode                    = Inp_RRM_TPMode;
      cfg.TP_Enabled                = (Inp_RRM_TPMode != TP_MODE_NONE);
      cfg.RRRatio                   = Inp_RRM_RRRatio;
      cfg.SwingLookback             = Inp_RRM_SwingLookback;
      cfg.SL_SwingPipsCushion       = GetRecommendedInitialSlCushionPips();
      cfg.SL_PsarPipsCushion        = GetRecommendedInitialSlCushionPips();
      cfg.FixedTPPips               = 40.0;
      cfg.SLPercent                 = 0.5;

      cfg.TrailMode                 = Inp_RRM_TrailMode;
      cfg.PSAR_TrailCushionMode     = PSAR_CUSHION_PIPS;
      cfg.PSAR_TrailPipsCushion     = GetRecommendedTrailPsarCushionPips();
      cfg.BE_Mode                   = BE_MODE_R_MULTIPLE;

      ENUM_TIMEFRAMES tfOrg         = (ENUM_TIMEFRAMES)_Period;
      cfg.TrailTrigger              = TRIGGER_BREAKEVEN;
      cfg.TrailDistancePips         = GetTFBasedCushion(tfOrg);
      cfg.BEThresholdPips           = GetTFBasedCushion(tfOrg);
      cfg.TrailLockProfit           = true;
      cfg.TrailProfitPercent        = 50.0;
      cfg.TrailStepPips             = 5.0;

      cfg.FractalPeriod             = 5;
      cfg.TPFractalOffset           = 1;

      // ── DRAWDOWN PROTECTION ───────────────────────────────────────────
      cfg.RRM_EnableDrawdownProtection = Inp_RRM_EnableDrawdownProtection;
      cfg.RRM_MaxConsecutiveLosses  = Inp_RRM_MaxConsecutiveLosses;
      cfg.RRM_MaxTradesPerDay       = Inp_RRM_MaxTradesPerDay;
      cfg.RRM_MaxDailyDrawdownPct   = Inp_RRM_MaxDailyDrawdownPct;

      // ── SLOPE CALCULATION ─────────────────────────────────────────────
      cfg.SlopeLookbackBars         = 1;
      cfg.ma_h_shift                = 0;
      cfg.ma_v_shift                = 1;

      // ── POLICY A: RESTORE OPERATOR-CONTROLLED GATES ───────────────────
      cfg.MaxSpread                 = op_MaxSpread;
      cfg.UseSpread                 = op_UseSpread;
      cfg.UseTime                   = op_UseTime;
      cfg.StartHr                   = op_StartHr;
      cfg.EndHr                     = op_EndHr;
      cfg.UseNews                   = op_UseNews;
      cfg.NewsPre                   = op_NewsPre;
      cfg.NewsPost                  = op_NewsPost;
      cfg.RiskPercent               = op_RiskPercent;
      cfg.MaxOpenTrades             = op_MaxOpenTrades;
      cfg.MaxTotalRisk              = op_MaxTotalRisk;
      cfg.MinMarginLevel            = op_MinMarginLevel;
      cfg.EmergencyMarginLevel      = op_EmergencyMarginLevel;

      // ── RE-ENTRY AFTER BREAKEVEN ──────────────────────────────────────
      cfg.AllowReEntryAfterBE       = true;

      // ── POST-TRADE COOLDOWN ───────────────────────────────────────────
      cfg.MinBarsAfterClose         = 3;

      // ── SPREAD RETRY CAP ─────────────────────────────────────────────
      cfg.MaxSpreadRetryBars        = 3;

      // ── EMA FAN OVEREXTENSION FILTER ──────────────────────────────────
      // EmaFanMaxTotalPips=25.0 is an empirically chosen starting point for
      // M1/M5 charts with the standard EMA5/13/34/89 fan. It represents the
      // approximate fan width at which trend exhaustion typically begins on
      // major FX pairs (e.g. EURUSD, GBPUSD). Adjust per instrument and TF:
      //   M15/H1: consider 40–60 pips; H4+: 80–120 pips.
      // JPY pairs: GlobalPipSize() returns the correct pip unit automatically.
      cfg.EmaFanFilterEnabled       = false;
      cfg.EmaFanMaxTotalPips        = 25.0;   // value retained for reference, filter is off

      // ── DPI DECELERATION FILTER ────────────────────────────────────────
      // DPI voter is enabled in PRESET_RRM_ORG — decel filter is active.
      cfg.DpiDecelFilterEnabled     = true;

      return;
   }
