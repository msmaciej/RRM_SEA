   if(preset == PRESET_RRM_ORG)
   {
      // ================================================================
      // PRESET_RRM_ORG: Original Russ Horn RRM with Inline DPI Voter
      // ================================================================
      //
      // SIGNAL FORMULA (all steps must pass):
      //   STEP 1: DPI (inline MACD) — momentum direction voter
      //   STEP 2: Phase (4-EMA) — UNORDERED blocked, EMERGING/TRENDING allowed
      //   STEP 3: Layer (EMA pair spacing) — WEAK/MEDIUM/STRONG
      //   STEP 4: Recovery gates — Gate_Recovery + Gate_EmaDiv
      //   STEP 5: Bar close (BC_LAYER_AWARE) — close vs role-based EMA
      //   STEP 6: PSAR + CandleBody confirmation
      //   → ENTRY SIGNAL
      //
      // LOCKED: DPI (inline MACD), PSAR, CandleBody, phase structure,
      //         recovery gates, bar close mode.
      // FLEXIBLE: MACD periods (via Zone 3D inputs), SL/TP/Trail modes.
      //
      // ── PHASE A QUALITY PATCH (TS=1 hardening, 2026-05) ──────────────
      // Targets four failure modes seen in 100-trades reference set:
      //   (B) EM→TM flicker entries → MinPhaseConfirmBars TF-scaled > 0
      //   (C) Late-trend / overextended fan entries → EmaFanFilterEnabled
      //       turned on with TF-scaled threshold (mirrors PRESET_RRM)
      //   (C) DPI deceleration leaks → DPI voter forced ON (was opt-in,
      //       which silently disabled the already-coded decel pre-filter)
      //   (D) Tangled-ribbon false TM → MinPhaseConfirmBars + recovery
      // Also fixes a duplicate-write bug on RequireRecoveryMomentum where
      // line 1309 (now removed) was unconditionally overwriting line 1295.
      // ================================================================

      // ── SIGNAL ARCHITECTURE: locked ──────────────────────────────────
      cfg.BiasMode               = BIAS_4EMA;
      cfg.AutoStrat              = STRAT_4EMA_LAYER;
      cfg.BiasFastID             = (int)ROLE_EMA3;    // EMA34: phase direction fast
      cfg.BiasSlowID             = (int)ROLE_EMA4;    // EMA89: phase direction slow
      cfg.MaType                 = METHOD_EMA;
      cfg.CloseOnReverse         = false;
      cfg.BiasEnabled            = true;
      cfg.RequirePriceCross      = false;
      cfg.MABenchmarkStrict      = false;
      cfg.UseMACompatSizer       = false;
      cfg.VoteMode               = VOTE_MODE_ALL;

      // ── EMA PERIODS: locked to RRM standard ──────────────────────────
      cfg.P_Ema1                 = 5;
      cfg.P_Ema2                 = 13;
      cfg.P_Ema3                 = 34;
      cfg.P_Ema4                 = 89;

      // ── DPI v31: LOCKED ON in RRM_ORG (matches reference screenshots) ──
      // PHASE A: was opt-in (false). The "ORG" suffix marks the original
      // Russ Horn methodology, which uses DPI as the primary momentum
      // voter — every entry shown in /100-trades/*.{jpg,png} has DPI in
      // the subwindow. Forcing it on also activates the DPI deceleration
      // pre-filter (line 4793 of SEA_SignalEngine.mqh) which was dead-code
      // until now because that filter requires Ind_Dpi_Enabled=true.
      cfg.Ind_Dpi_Enabled          = true;
      cfg.Ind_Dpi_Weight           = 1;
      cfg.DPI_MACD_Fast            = Inp_RRM_ORG_MACD_Fast;              // default 8
      cfg.DPI_MACD_Slow            = Inp_RRM_ORG_MACD_Slow;              // default 13
      cfg.DPI_RedSignalType        = Inp_RRM_ORG_DPI_RedSignalType;      // default 3 (EMA13)
      cfg.DPI_RedEMA_A             = Inp_RRM_ORG_DPI_RedEMA_A;           // default 5
      cfg.DPI_RedEMA_B             = Inp_RRM_ORG_DPI_RedEMA_B;           // default 8
      cfg.DPI_RedEMA_C             = Inp_RRM_ORG_DPI_RedEMA_C;           // default 13
      cfg.DPI_RedEMA_D             = Inp_RRM_ORG_DPI_RedEMA_D;           // default 21
      cfg.DPI_DoubleSmoothFirst    = Inp_RRM_ORG_DPI_DoubleSmoothFirst;  // default 5
      cfg.DPI_DoubleSmoothSecond   = Inp_RRM_ORG_DPI_DoubleSmoothSecond; // default 8
      cfg.DPI_UseCCIReset          = Inp_RRM_ORG_DPI_UseCCIReset;        // default true
      cfg.DPI_CCI_Period           = Inp_RRM_ORG_DPI_CCI_Period;         // default 13
      cfg.DPI_CCI_AppliedPrice     = (int)Inp_RRM_ORG_DPI_CCI_Price;     // default PRICE_TYPICAL
      cfg.DPI_UseGreenHist         = Inp_RRM_ORG_DPI_UseGreenHist;       // default true

      // ── PSAR: LOCKED ON (timing/direction confirmation) ───────────────
      cfg.Ind_Psar_Enabled       = true;
      cfg.P_PsarStep             = 0.05;
      cfg.P_PsarMax              = 0.5;
      cfg.Vote_AllowPsarFlip     = true;
      cfg.Vote_PsarFlipDelay     = -1;   // Persistent: evaluate dot position on every bar

      // ── CANDLE BODY ───────────────────────────────────────────────────
      cfg.Ind_CandleBody_Enabled      = Inp_Ind_CandleBody_Enabled;
      cfg.Ind_CandleBody_Weight       = 1;
      cfg.CandleBody_AvgPeriod        = Inp_Ind_CandleBody_AvgPeriod;
      cfg.CandleBody_MaxMult          = Inp_Ind_CandleBody_MaxMult;
      cfg.CandleBody_CheckBars        = Inp_Ind_CandleBody_CheckBars;
      // cfg.CandleBody_CheckBars   = (_Period <= PERIOD_M5) ? 3 : 5;
      cfg.CandleBody_RequireDirection = Inp_Ind_CandleBody_RequireDirection;
      
      // ── ALL OTHER INDICATORS: LOCKED OFF ─────────────────────────────
      cfg.Ind_Adx_Enabled        = false;
      cfg.Ind_Atr_Enabled        = false;
      cfg.Ind_Bb_Enabled         = false;
      cfg.Ind_CI_Enabled         = false;
      cfg.Ind_VRC_Enabled        = false;
      cfg.Ind_Cci_Enabled        = false;
      cfg.Ind_Macd_Enabled       = false;
      cfg.Ind_Mfi_Enabled        = false;
      cfg.Ind_P123_Enabled       = false;
      cfg.Ind_Ross_Enabled       = false;
      cfg.Ind_Rsi_Enabled        = false;
      cfg.Ind_Sto_Enabled        = false;
      cfg.Ind_SmaConverge_Enabled = false;
      cfg.Ind_SmaConverge_Weight  = 1;

      // ── ADX SETTINGS: safe defaults (disabled) ────────────────────────
      cfg.P_Adx                  = 14;
      cfg.T_Adx                  = 20.0;
      cfg.ADX_Mode               = ADX_MODE_STATIC;
      cfg.ADX_Percentile         = 50.0;
      cfg.ADX_Lookback           = 100;
      cfg.ADX_Threshold_Accumulation  = 12.0;
      cfg.ADX_Threshold_Trending      = 25.0;
      cfg.ADX_Threshold_Distribution  = 18.0;

      // ── ATR SETTINGS: safe defaults (disabled) ────────────────────────
      cfg.P_Atr                  = 14;
      cfg.ATR_VoteMinPips        = 5.0;
      cfg.ATR_VoteMaxPips        = 50.0;

      // ── MACD SETTINGS: safe defaults (disabled) ───────────────────────
      cfg.P_MacdFast             = 8;  // 12
      cfg.P_MacdSlow             = 13; // 26
      cfg.P_MacdSig              = 5;  //  9
      cfg.MacdVoteMode           = MACD_HISTOGRAM;
      cfg.MacdRequireSlope       = false;
      cfg.MacdRequireDivergence  = false;
      cfg.MacdRequireHook        = false;
      cfg.MacdFreshBars          = 3;
      cfg.MacdSlopeMin           = 0.00001;

      // ── CCI/RSI/STOCH/BB/MFI: safe defaults (all disabled) ───────────
      cfg.P_Cci                  = 14;
      cfg.CciMode                = CCI_TREND_ZERO;
      cfg.P_Rsi                  = 14;
      cfg.T_RsiOB                = 70.0;
      cfg.T_RsiOS                = 30.0;
      cfg.RsiMode                = RSI_TREND_ABOVE_50;
      cfg.P_StoK                 = 5;
      cfg.P_StoD                 = 3;
      cfg.P_StoSlow              = 3;
      cfg.T_StoOB                = 80.0;
      cfg.T_StoOS                = 20.0;
      cfg.StoMode                = STO_CROSS_SIGNAL;
      cfg.P_Bb                   = 20;
      cfg.P_BbDev                = 2.0;
      cfg.BbMode                 = BB_TREND_FOLLOW;
      cfg.P_Mfi                  = 14;
      cfg.T_MfiOB                = 80.0;
      cfg.T_MfiOS                = 20.0;
      cfg.MfiMode                = MFI_ZONE_FILTER;

      // ── CI/VRC: safe defaults (disabled) ─────────────────────────────
      cfg.CI_Period              = 14;
      cfg.CI_RangingThreshold    = 61.8;
      cfg.Ind_CI_Weight          = 1;
      cfg.VRC_ATR_Period         = 14;
      cfg.VRC_Lookback           = 100;
      cfg.VRC_LowThreshold       = 33.0;
      cfg.Ind_VRC_Weight         = 1;

      // ── BAR CLOSE (bcX): LOCKED to layer-aware ───────────────────────
      cfg.BarClose_Enabled       = true;
      cfg.BarClose_Mode          = BC_LAYER_AWARE;   // bcW=EMA1, bcM=EMA2, bcS=EMA3
      cfg.BarClose_DefaultEMA    = ROLE_EMA1;

      // ── PHASE DETECTION & LAYER FILTERING: LOCKED ON ─────────────────
      cfg.PhaseDetectionEnabled     = true;
      cfg.EnableLayerDetection      = true;
      cfg.BlockUnorderedPhase       = true;           // UNORDERED → block all trades
      cfg.BlockEmergingPhase        = true;           // true: EM phase = no trades; TM phase = trades allowed

      // PHASE A: TF-scaled phase-age confirmation. The previous setting
      // (0 on every TF) lets a single bar that flickers into TM after UNO
      // qualify as a setup — see trade #095 (EURJPY M5) and #075 (USDJPY
      // M5) where the entry bar is the first/second TM bar after a
      // tangled-ribbon zone and price reverses immediately. Requiring
      // 1–3 bars of phase persistence kills these flickers cheaply.
      cfg.MinPhaseConfirmBars       = (_Period <= PERIOD_M5)  ? 1
                                    : (_Period <= PERIOD_M30) ? 2
                                    :                           3;

      // EMERGING phase: WEAK + MEDIUM only; STRONG always blocked per RRM methodology
      cfg.Emerging_AllowWeakTrades   = Inp_RRM_AllowWeak;
      cfg.Emerging_AllowMediumTrades = Inp_RRM_AllowMedium;
      cfg.Emerging_AllowStrongTrades = false;         // STRONG always blocked in EMERGING per RRM methodology

      // TRENDING phase: controlled by layer filter inputs (Inp_RRM_Allow*)
      cfg.Trending_AllowWeakTrades   = Inp_RRM_AllowWeak;
      cfg.Trending_AllowMediumTrades = Inp_RRM_AllowMedium;
      cfg.Trending_AllowStrongTrades = Inp_RRM_AllowStrong;

      // ── PULLBACK DETECTION GATES: LOCKED ON ──────────────────────────
      // PHASE A: require recovery momentum on M15-and-down. The original
      // code set it true on M5 then immediately overwrote with `false` on
      // a second line — duplicate-write bug. Wick-touch recoveries are
      // the dominant noise mode on intraday, see trade #095.
      cfg.RequireRecoveryMomentum   = (_Period <= PERIOD_M15);

      cfg.Gate_Recovery.mode        = GATE_SCALE_AUTO_TF;
      // PHASE A: JPY pairs run ~1.3× the natural noise vs majors at the
      // same TF. Loosen recovery distance proportionally so we don't chop
      // out of legitimate setups (#001 USDJPY, #060 GBPJPY, #100 EURJPY).
      {
         bool isJpyOrg = (StringFind(_Symbol, "JPY") >= 0);
         cfg.Gate_Recovery.value = isJpyOrg ? 1.3 : 1.0;
         cfg.Gate_EmaDiv.value   = isJpyOrg ? 1.3 : 1.0;
      }
      cfg.RRM_Lookback              = (_Period <= PERIOD_M1) ? 15 : (_Period <= PERIOD_M5) ? 10 : 12;

      cfg.Gate_EmaDiv.mode          = GATE_SCALE_AUTO_TF;
      cfg.RRM_MinDivPips            = 1.5;

      cfg.Gate_CandleDirection.mode  = GATE_SCALE_FIXED;
      cfg.Gate_CandleDirection.value = 1.0;

      // ── VOTE EVALUATION ───────────────────────────────────────────────
      cfg.Vote_EvalShift            = 1;

      // ── RISK MANAGEMENT ───────────────────────────────────────────────
      cfg.CountBEasZeroRisk         = true;
      cfg.FixedLotSize              = 0.0;

      // ── EXIT STRATEGY: flexible (uses RRM profile, SL/TP from inputs) ─
      cfg.ExitProfile               = EXIT_PROFILE_RRM;
      cfg.SLMode                    = Inp_RRM_SLMode;
      cfg.TPMode                    = Inp_RRM_TPMode;
      cfg.TP_Enabled                = (Inp_RRM_TPMode != TP_MODE_NONE);
      cfg.RRRatio                   = Inp_RRM_RRRatio;
      cfg.SwingLookback             = Inp_RRM_SwingLookback;
      cfg.SL_SwingPipsCushion       = GetRecommendedInitialSlCushionPips();
      cfg.SL_PsarPipsCushion        = GetRecommendedInitialSlCushionPips();
      cfg.FixedTPPips               = 40.0;
      cfg.SLPercent                 = 0.5;

      cfg.TrailMode                 = Inp_RRM_TrailMode;
      cfg.PSAR_TrailCushionMode     = PSAR_CUSHION_PIPS;
      cfg.PSAR_TrailPipsCushion     = GetRecommendedTrailPsarCushionPips();
      cfg.BE_Mode                   = BE_MODE_R_MULTIPLE;

      ENUM_TIMEFRAMES tfOrg         = (ENUM_TIMEFRAMES)_Period;
      cfg.TrailTrigger              = TRIGGER_BREAKEVEN;
      cfg.TrailDistancePips         = GetTFBasedCushion(tfOrg);
      cfg.BEThresholdPips           = GetTFBasedCushion(tfOrg);
      cfg.TrailLockProfit           = true;
      cfg.TrailProfitPercent        = 50.0;
      cfg.TrailStepPips             = 5.0;

      cfg.FractalPeriod             = 5;
      cfg.TPFractalOffset           = 1;

      // ── DRAWDOWN PROTECTION ───────────────────────────────────────────
      // PHASE A: force-on for ORG (a "quality-first" preset). User can
      // still tune the thresholds via Inp_RRM_Max* inputs.
      cfg.RRM_EnableDrawdownProtection = true;
      cfg.RRM_MaxConsecutiveLosses  = (Inp_RRM_MaxConsecutiveLosses > 0) ? Inp_RRM_MaxConsecutiveLosses : 4;
      cfg.RRM_MaxTradesPerDay       = Inp_RRM_MaxTradesPerDay;
      cfg.RRM_MaxDailyDrawdownPct   = (Inp_RRM_MaxDailyDrawdownPct  > 0.0) ? Inp_RRM_MaxDailyDrawdownPct  : 2.0;

      // ── SLOPE CALCULATION ─────────────────────────────────────────────
      cfg.SlopeLookbackBars         = 1;
      cfg.ma_h_shift                = 0;
      cfg.ma_v_shift                = 1;

      // ── POLICY A: RESTORE OPERATOR-CONTROLLED GATES ───────────────────
      cfg.MaxSpread                 = op_MaxSpread;
      cfg.UseSpread                 = op_UseSpread;
      cfg.UseTime                   = op_UseTime;
      cfg.StartHr                   = op_StartHr;
      cfg.EndHr                     = op_EndHr;
      cfg.UseNews                   = op_UseNews;
      cfg.NewsPre                   = op_NewsPre;
      cfg.NewsPost                  = op_NewsPost;
      cfg.RiskPercent               = op_RiskPercent;
      cfg.MaxOpenTrades             = op_MaxOpenTrades;
      cfg.MaxTotalRisk              = op_MaxTotalRisk;
      cfg.MinMarginLevel            = op_MinMarginLevel;
      cfg.EmergencyMarginLevel      = op_EmergencyMarginLevel;

      // PHASE A: HTF trend filter ON by default. Trades like #075
      // (USDJPY M5 LONG against the H1/H4 picture) are exactly what an
      // HTF gate is meant to suppress. User can still disable via
      // Inp_UseHTF=false; default remains restrictive.
      cfg.UseHTF                    = (Inp_UseHTF || true);   // force-true override
      cfg.HtfPeriod                 = (Inp_HtfPeriod != PERIOD_CURRENT) ? Inp_HtfPeriod
                                    : ((_Period <= PERIOD_M5)  ? PERIOD_M30
                                    :  (_Period <= PERIOD_M30) ? PERIOD_H1
                                    :  (_Period <= PERIOD_H1)  ? PERIOD_H4
                                    :                            PERIOD_D1);
      cfg.P_HtfEma                  = (Inp_HtfEmaPeriod > 0) ? Inp_HtfEmaPeriod : 89;

      // ── RE-ENTRY AFTER BREAKEVEN ──────────────────────────────────────
      cfg.AllowReEntryAfterBE       = true;

      // ── POST-TRADE COOLDOWN ───────────────────────────────────────────
      cfg.MinBarsAfterClose         = 3;

      // ── SPREAD RETRY CAP ─────────────────────────────────────────────
      cfg.MaxSpreadRetryBars        = 3;

      // ── EMA FAN OVEREXTENSION FILTER ──────────────────────────────────
      // PHASE A: turned ON with TF-scaled threshold. The previous setting
      // (false / 25 pips) silently disabled the filter entirely. The 25-pip
      // value is correct only for M1/M5; H4 and Daily fan widths in the
      // dataset routinely exceed 80–150 pips on legitimate trends, so a
      // single hardcoded threshold can't work across the TF range we see.
      // The engine logic at SEA_SignalEngine.mqh:4754 only rejects when
      // `gap_now > max && gap_now > gap_prev` (i.e. still expanding), so
      // late-trend chases like #075 are blocked while fresh impulses pass.
      cfg.EmaFanFilterEnabled       = true;
      cfg.EmaFanMaxTotalPips        = (_Period <= PERIOD_M5)  ?  25.0
                                    : (_Period <= PERIOD_M30) ?  40.0
                                    : (_Period <= PERIOD_H1)  ?  60.0
                                    : (_Period <= PERIOD_H4)  ? 100.0
                                    :                           180.0;  // D1+

      // ── DPI DECELERATION FILTER ────────────────────────────────────────
      // PHASE A: now actually active because Ind_Dpi_Enabled is true above.
      cfg.DpiDecelFilterEnabled     = true;

      return;
   }
