// ============================================================================
//  PHASE B PATCH — SEA_Config.mqh additions
//  Operator-toggleable inputs for the Phase A hardening of PRESET_RRM_ORG.
//  Each new input has a sensible default that keeps Phase A behavior; users
//  can dial each gate down (or off) without editing source code.
//
//  Where to insert:
//    All inputs go inside the existing "PRESET: RRM_ORG" group block in
//    SEA_Config.mqh — directly AFTER the line:
//         input bool  Inp_RRM_ORG_DPI_UseGreenHist  = false;
//    (current line ~974). Adding them here keeps them next to the other
//    RRM_ORG-scoped controls in the MT5 dialog.
//
//  Struct field additions (also Phase B):
//    Append the four new fields to the ST_Settings struct in SEA_Config.mqh
//    near the existing TE-related cluster (HtfPeriod, MaxSpreadRetryBars,
//    EmaFanFilterEnabled, etc., around line 614–625). Mirror them in
//    InitializeConfig() so default values flow from inputs to runtime.
//
//  Compatibility:
//    All defaults reproduce Phase A behavior exactly. Existing presets
//    other than PRESET_RRM_ORG are unaffected because they don't reference
//    these fields. The TE_* fields are read by SEA_TradeExecutor::EvaluateTE
//    only when their enable flags are true.
// ============================================================================


// -----------------------------------------------------------------------------
//  STEP 1 — Add this input group inside SEA_Config.mqh, immediately after the
//           line `input bool Inp_RRM_ORG_DPI_UseGreenHist = false;` (~line 974)
// -----------------------------------------------------------------------------

input group "╔════════════════════════════════════════════════════════╗";
input group "║   📐 RRM_ORG: Phase A Quality Gates (TS=1 / TE=1)";
input group "╚════════════════════════════════════════════════════════╝";

// ── TS-side gates (signal evaluation, shift=1) ────────────────────────────────

input bool   Inp_RRM_ORG_ForceDpiOn          = true;   // RRM_ORG: Force DPI voter ON (matches reference methodology)

input bool   Inp_RRM_ORG_EmaFanFilter        = true;   // RRM_ORG: Block entry on overextended EMA fan
input double Inp_RRM_ORG_EmaFan_M5Pips       = 25.0;   // RRM_ORG: Fan max pips on M1–M5
input double Inp_RRM_ORG_EmaFan_M30Pips      = 40.0;   // RRM_ORG: Fan max pips on M6–M30
input double Inp_RRM_ORG_EmaFan_H1Pips       = 60.0;   // RRM_ORG: Fan max pips on H1
input double Inp_RRM_ORG_EmaFan_H4Pips       = 100.0;  // RRM_ORG: Fan max pips on H4
input double Inp_RRM_ORG_EmaFan_DailyPips    = 180.0;  // RRM_ORG: Fan max pips on D1+

input int    Inp_RRM_ORG_PhaseConfirmM5      = 1;      // RRM_ORG: MinPhaseConfirmBars on M1–M5
input int    Inp_RRM_ORG_PhaseConfirmM30     = 2;      // RRM_ORG: MinPhaseConfirmBars on M6–M30
input int    Inp_RRM_ORG_PhaseConfirmH1plus  = 3;      // RRM_ORG: MinPhaseConfirmBars on H1 and above

input bool   Inp_RRM_ORG_RequireRecoveryIntraday = true;  // RRM_ORG: Require recovery momentum on M15-and-down
input double Inp_RRM_ORG_JpyGateMultiplier   = 1.3;    // RRM_ORG: Recovery+EmaDiv gate scale for JPY pairs (1.0=disabled)

input bool   Inp_RRM_ORG_HtfFilter           = true;   // RRM_ORG: Force HTF trend filter ON
input int    Inp_RRM_ORG_HtfEmaPeriod        = 89;     // RRM_ORG: HTF EMA period (0=use Inp_HtfEmaPeriod)

input bool   Inp_RRM_ORG_DpiDecelFilter      = true;   // RRM_ORG: Block entry on DPI histogram deceleration

input bool   Inp_RRM_ORG_ForceDDProtection   = true;   // RRM_ORG: Force drawdown protection ON
input int    Inp_RRM_ORG_DDMaxConsecLosses   = 4;      // RRM_ORG: Override max consecutive losses (0=use Inp_RRM_*)
input double Inp_RRM_ORG_DDMaxDailyPct       = 2.0;    // RRM_ORG: Override max daily DD %% (0=use Inp_RRM_*)

// ── TE-side gates (execution evaluation, shift=0) ─────────────────────────────

input bool   Inp_RRM_ORG_TE_RecheckBarClose  = true;   // RRM_ORG: At TE, re-confirm shift=1 BC vs current bid
input int    Inp_RRM_ORG_TE_OpenDelaySecsM5  = 10;     // RRM_ORG: Defer TE by N sec at new bar (M1–M5)
input int    Inp_RRM_ORG_TE_OpenDelaySecsM30 = 5;      // RRM_ORG: Defer TE by N sec at new bar (M6–M30)
input int    Inp_RRM_ORG_TE_OpenDelaySecsHi  = 0;      // RRM_ORG: Defer TE by N sec at new bar (H1+)
input int    Inp_RRM_ORG_TE_SpreadMedianTicks = 8;     // RRM_ORG: Median spread over last N ticks (0=disabled)


// -----------------------------------------------------------------------------
//  STEP 2 — Add these fields to ST_Settings in SEA_Config.mqh
//           (place them next to the existing EmaFanFilterEnabled cluster,
//            current line ~620, so all "Phase A/B quality gates" live together)
// -----------------------------------------------------------------------------

   // ── PHASE B: TE-side hardening fields (read by SEA_TradeExecutor) ─────────
   bool   TE_RecheckBarClose;       // Re-confirm bar-close BC vs live bid at shift=0
   int    TE_OpenDelaySeconds;      // Defer EvaluateTE() by N sec after new bar
   int    TE_SpreadMedianTicks;     // Median spread over last N ticks (0=disabled)


// -----------------------------------------------------------------------------
//  STEP 3 — Add these mirror lines inside InitializeConfig() in SEA_Config.mqh
//           (place near the existing `Settings.EmaFanFilterEnabled = ...`
//            mirror, current line ~1596)
// -----------------------------------------------------------------------------

   Settings.TE_RecheckBarClose      = false;     // default off; PRESET_RRM_ORG turns it on
   Settings.TE_OpenDelaySeconds     = 0;         // default 0 (no delay); preset overrides
   Settings.TE_SpreadMedianTicks    = 0;         // default 0 (use raw spread); preset overrides


// -----------------------------------------------------------------------------
//  STEP 4 — Replace the Phase A hardcoded values in SEA_Presets.mqh
//           PRESET_RRM_ORG block with these input-driven assignments.
//           This makes every Phase A gate operator-toggleable without
//           changing the default behavior.
//
//  Replace the corresponding lines from the Phase A patch:
// -----------------------------------------------------------------------------

      // ── DPI v31: LOCKED ON (overridable) ──────────────────────────────────
      cfg.Ind_Dpi_Enabled          = Inp_RRM_ORG_ForceDpiOn;

      // ── PHASE-AGE CONFIRMATION (input-driven) ─────────────────────────────
      cfg.MinPhaseConfirmBars       = (_Period <= PERIOD_M5)  ? Inp_RRM_ORG_PhaseConfirmM5
                                    : (_Period <= PERIOD_M30) ? Inp_RRM_ORG_PhaseConfirmM30
                                    :                           Inp_RRM_ORG_PhaseConfirmH1plus;

      // ── RECOVERY MOMENTUM (input-driven) ──────────────────────────────────
      cfg.RequireRecoveryMomentum   = Inp_RRM_ORG_RequireRecoveryIntraday && (_Period <= PERIOD_M15);

      // ── JPY GATE SCALING (input-driven) ───────────────────────────────────
      {
         bool isJpyOrg = (StringFind(_Symbol, "JPY") >= 0);
         double jpyMul = (Inp_RRM_ORG_JpyGateMultiplier > 0.0) ? Inp_RRM_ORG_JpyGateMultiplier : 1.0;
         cfg.Gate_Recovery.value = isJpyOrg ? jpyMul : 1.0;
         cfg.Gate_EmaDiv.value   = isJpyOrg ? jpyMul : 1.0;
      }

      // ── DRAWDOWN PROTECTION (input-driven) ────────────────────────────────
      cfg.RRM_EnableDrawdownProtection = Inp_RRM_ORG_ForceDDProtection || Inp_RRM_EnableDrawdownProtection;
      cfg.RRM_MaxConsecutiveLosses     = (Inp_RRM_ORG_DDMaxConsecLosses > 0)
                                            ? Inp_RRM_ORG_DDMaxConsecLosses
                                            : Inp_RRM_MaxConsecutiveLosses;
      cfg.RRM_MaxTradesPerDay          = Inp_RRM_MaxTradesPerDay;
      cfg.RRM_MaxDailyDrawdownPct      = (Inp_RRM_ORG_DDMaxDailyPct > 0.0)
                                            ? Inp_RRM_ORG_DDMaxDailyPct
                                            : Inp_RRM_MaxDailyDrawdownPct;

      // ── HTF FILTER (input-driven) ─────────────────────────────────────────
      cfg.UseHTF                    = Inp_RRM_ORG_HtfFilter || Inp_UseHTF;
      cfg.HtfPeriod                 = (Inp_HtfPeriod != PERIOD_CURRENT) ? Inp_HtfPeriod
                                    : ((_Period <= PERIOD_M5)  ? PERIOD_M30
                                    :  (_Period <= PERIOD_M30) ? PERIOD_H1
                                    :  (_Period <= PERIOD_H1)  ? PERIOD_H4
                                    :                            PERIOD_D1);
      cfg.P_HtfEma                  = (Inp_RRM_ORG_HtfEmaPeriod > 0)
                                            ? Inp_RRM_ORG_HtfEmaPeriod
                                            : (Inp_HtfEmaPeriod > 0 ? Inp_HtfEmaPeriod : 89);

      // ── EMA FAN FILTER (input-driven) ─────────────────────────────────────
      cfg.EmaFanFilterEnabled       = Inp_RRM_ORG_EmaFanFilter;
      cfg.EmaFanMaxTotalPips        = (_Period <= PERIOD_M5)  ? Inp_RRM_ORG_EmaFan_M5Pips
                                    : (_Period <= PERIOD_M30) ? Inp_RRM_ORG_EmaFan_M30Pips
                                    : (_Period <= PERIOD_H1)  ? Inp_RRM_ORG_EmaFan_H1Pips
                                    : (_Period <= PERIOD_H4)  ? Inp_RRM_ORG_EmaFan_H4Pips
                                    :                           Inp_RRM_ORG_EmaFan_DailyPips;

      // ── DPI DECEL FILTER (input-driven) ───────────────────────────────────
      cfg.DpiDecelFilterEnabled     = Inp_RRM_ORG_DpiDecelFilter;

      // ── TE-side gates (input-driven) ──────────────────────────────────────
      cfg.TE_RecheckBarClose        = Inp_RRM_ORG_TE_RecheckBarClose;
      cfg.TE_OpenDelaySeconds       = (_Period <= PERIOD_M5)  ? Inp_RRM_ORG_TE_OpenDelaySecsM5
                                    : (_Period <= PERIOD_M30) ? Inp_RRM_ORG_TE_OpenDelaySecsM30
                                    :                           Inp_RRM_ORG_TE_OpenDelaySecsHi;
      cfg.TE_SpreadMedianTicks      = Inp_RRM_ORG_TE_SpreadMedianTicks;


// -----------------------------------------------------------------------------
//  STEP 5 — SEA_TradeExecutor.mqh: implement the three TE gates
//           Insert this block at the START of EvaluateTE(), right after the
//           `m_te_veto_reason = "OK";` line (current line 1601).
//           Each guard is a no-op when its enable flag/threshold is 0/false,
//           so behavior is unchanged for all other presets.
// -----------------------------------------------------------------------------

      // ── PHASE B GATE 1: open-tick delay ───────────────────────────────────
      // Defer TE by N seconds after a new bar opens. Bid/ask spreads spike
      // hardest at the bar boundary (esp. on M1/M5 around session opens).
      // Skipping TE entirely in the first N seconds lets the spike resolve.
      if(m_settings.TE_OpenDelaySeconds > 0) {
         datetime bar0_open = (datetime)SeriesInfoInteger(m_symbol, PERIOD_CURRENT, SERIES_LASTBAR_DATE);
         long age_sec       = (long)(TimeCurrent() - bar0_open);
         if(age_sec >= 0 && age_sec < m_settings.TE_OpenDelaySeconds) {
            m_te_veto_reason = "VETO_OPEN_DELAY";
            if(m_settings.DebugFlow)
               PrintFormat("[TE] VETO_OPEN_DELAY: bar age=%d sec < %d sec required",
                           (int)age_sec, m_settings.TE_OpenDelaySeconds);
            return 0;
         }
      }

      // ── PHASE B GATE 2: bar-close BC re-check ─────────────────────────────
      // The TS=1 setup was confirmed at shift=1 close. By the time TE fires
      // at shift=0, price may have gapped through the layer EMA in the
      // wrong direction. Re-check that the last bar's close is still on
      // the correct side of the *layer-aware* EMA at current bid.
      if(m_settings.TE_RecheckBarClose) {
         double close1   = iClose(m_symbol, PERIOD_CURRENT, 1);
         double bid_now  = SymbolInfoDouble(m_symbol, SYMBOL_BID);
         // A 2× pip cushion is the noise tolerance — anything more than this
         // against bias means the setup is stale.
         double pip      = GlobalPipSize(m_symbol);
         double drift    = isBuy ? (close1 - bid_now) : (bid_now - close1);
         double max_drift_pips = 2.0;
         if(pip > 0.0 && drift / pip > max_drift_pips) {
            m_te_veto_reason = "VETO_BC_STALE";
            if(m_settings.DebugFlow)
               PrintFormat("[TE] VETO_BC_STALE: drift=%.1f pips > %.1f (close1=%.5f bid=%.5f)",
                           drift / pip, max_drift_pips, close1, bid_now);
            return 0;
         }
      }

      // ── PHASE B GATE 3: spread median (handled inside EvaluateF) ──────────
      // When TE_SpreadMedianTicks > 0, EvaluateF compares the median of the
      // last N tick spreads against MaxSpread instead of the instant spread.
      // Implementation note: requires a small ring buffer in the executor;
      // see EvaluateF patch below for the 12-line addition.

// -----------------------------------------------------------------------------
//  STEP 6 — SEA_TradeExecutor.mqh: median-spread support inside EvaluateF
//           (replaces the existing single-tick spread comparison)
// -----------------------------------------------------------------------------

   // Ring buffer (add to the class private members, near m_spread_block_bars):
   double      m_spread_history[32];   // sized for max plausible TE_SpreadMedianTicks
   int         m_spread_history_count;
   int         m_spread_history_idx;

   // Inside EvaluateF, replace the line:
   //     double spread_pips = (ask - bid) / pip;
   // with:
   double spread_inst = (ask - bid) / pip;
   double spread_pips = spread_inst;
   int N = m_settings.TE_SpreadMedianTicks;
   if(N > 0 && N <= 32) {
      m_spread_history[m_spread_history_idx % N] = spread_inst;
      m_spread_history_idx++;
      if(m_spread_history_count < N) m_spread_history_count++;
      if(m_spread_history_count == N) {
         // Insertion sort copy and pick median (N is small, this is cheap)
         double tmp[32];
         for(int i = 0; i < N; i++) tmp[i] = m_spread_history[i];
         for(int i = 1; i < N; i++) {
            double key = tmp[i]; int j = i - 1;
            while(j >= 0 && tmp[j] > key) { tmp[j+1] = tmp[j]; j--; }
            tmp[j+1] = key;
         }
         spread_pips = (N % 2 == 1) ? tmp[N/2] : 0.5 * (tmp[N/2 - 1] + tmp[N/2]);
      }
   }
