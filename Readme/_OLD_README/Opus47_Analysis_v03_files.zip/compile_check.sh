#!/usr/bin/env bash
# =============================================================================
# compile_check.sh — MetaEditor compile wrapper for macOS+Wine+MT5
# =============================================================================
#
# Wraps `metaeditor64.exe /compile:... /inc:... /log:...` for use after each
# step of the Phase A / A.1 patch series. Designed for the SimpleEA repo's
# documented environment: macOS + Wine + MT5, MQL5 only.
#
# Usage (most common):
#   ./compile_check.sh
#       Compiles SimpleEA_v1-03.mq5 with the include paths set automatically.
#       Exits 0 on success, 1 on compile failure.
#
#   ./compile_check.sh --syntax-only
#       Adds /s flag — fastest check, skips the .ex5 generation step.
#
#   ./compile_check.sh --step 3
#       Same as the default compile, but tags the log file with the Phase A.1
#       step number so you can keep a per-step audit trail.
#
#   ./compile_check.sh --diff-prev
#       After compiling, prints the DIFFERENCE in error/warning counts vs.
#       the previous run. Useful to confirm a step didn't introduce new
#       compiler warnings even when the build succeeds.
#
# Configuration — edit the three CONFIG variables below for your setup,
# OR set them as environment variables before invoking. The script also
# auto-detects the most common Wine paths.
#
# Exit codes:
#   0  — compile succeeded with 0 errors (warnings allowed unless --strict)
#   1  — compile failed (errors > 0)
#   2  — could not locate metaeditor64.exe or the EA file
#   3  — invalid arguments
# =============================================================================

set -uo pipefail

# -----------------------------------------------------------------------------
# CONFIG — edit these or set as environment variables before invoking
# -----------------------------------------------------------------------------

# Where your MetaTrader 5 lives under Wine. The script looks here first, then
# falls back to a few common locations.
DEFAULT_METAEDITOR="${SEA_METAEDITOR:-$HOME/.wine/drive_c/Program Files/MetaTrader 5/metaeditor64.exe}"

# Your MQL5 directory — the parent of Experts/, Include/, Indicators/, etc.
# Under Wine on macOS, this is typically inside ~/.wine/drive_c/Users/<user>/AppData/Roaming/MetaQuotes/Terminal/<hash>/MQL5
# but some setups put it under Program Files/MetaTrader 5/MQL5 directly.
DEFAULT_MQL5_DIR="${SEA_MQL5_DIR:-}"

# The EA file to compile, relative to MQL5_DIR/Experts/ (without the path).
DEFAULT_EA_FILE="${SEA_EA_FILE:-RRMS/SimpleEA_v1-03.mq5}"

# Where to put per-run compile logs (used by --diff-prev to compare runs).
LOG_DIR="${SEA_LOG_DIR:-$HOME/.sea_compile_logs}"

# -----------------------------------------------------------------------------
# Argument parsing
# -----------------------------------------------------------------------------

SYNTAX_ONLY=0
STEP_TAG=""
DIFF_PREV=0
STRICT=0
EA_FILE_OVERRIDE=""

usage() {
    sed -n '3,50p' "$0" | sed 's/^# \?//'
    exit 3
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --syntax-only) SYNTAX_ONLY=1; shift ;;
        --step)        STEP_TAG="step${2}"; shift 2 ;;
        --diff-prev)   DIFF_PREV=1; shift ;;
        --strict)      STRICT=1; shift ;;
        --file)        EA_FILE_OVERRIDE="$2"; shift 2 ;;
        --help|-h)     usage ;;
        *)             echo "ERROR: unknown argument: $1" >&2; usage ;;
    esac
done

# -----------------------------------------------------------------------------
# Locate metaeditor64.exe
# -----------------------------------------------------------------------------

METAEDITOR=""
if [[ -f "$DEFAULT_METAEDITOR" ]]; then
    METAEDITOR="$DEFAULT_METAEDITOR"
else
    # Try a few known fallbacks
    for candidate in \
        "$HOME/.wine/drive_c/Program Files/MetaTrader 5/metaeditor64.exe" \
        "$HOME/.wine/drive_c/Program Files (x86)/MetaTrader 5/metaeditor64.exe" \
        "/Applications/MetaTrader 5.app/Contents/Resources/drive_c/Program Files/MetaTrader 5/metaeditor64.exe" \
        "/Applications/PlayOnMac.app/Contents/Resources/wine/MetaTrader 5/metaeditor64.exe"
    do
        if [[ -f "$candidate" ]]; then
            METAEDITOR="$candidate"
            break
        fi
    done
fi

if [[ -z "$METAEDITOR" ]]; then
    cat >&2 <<EOF
ERROR: could not locate metaeditor64.exe.

Tried:
  $DEFAULT_METAEDITOR
  ~/.wine/drive_c/Program Files/MetaTrader 5/metaeditor64.exe
  ~/.wine/drive_c/Program Files (x86)/MetaTrader 5/metaeditor64.exe
  /Applications/MetaTrader 5.app/Contents/Resources/drive_c/Program Files/MetaTrader 5/metaeditor64.exe
  /Applications/PlayOnMac.app/Contents/Resources/wine/MetaTrader 5/metaeditor64.exe

Set the path explicitly:
  export SEA_METAEDITOR="/path/to/metaeditor64.exe"
  $0
EOF
    exit 2
fi

# -----------------------------------------------------------------------------
# Locate MQL5 directory
# -----------------------------------------------------------------------------

MQL5_DIR="$DEFAULT_MQL5_DIR"

if [[ -z "$MQL5_DIR" ]]; then
    # Try the directory next to metaeditor64.exe first (Program Files install)
    me_dir="$(dirname "$METAEDITOR")"
    if [[ -d "$me_dir/MQL5" ]]; then
        MQL5_DIR="$me_dir/MQL5"
    else
        # Look for the AppData\Roaming Terminal hash directory (most common for Wine)
        # Pick the first one that has MQL5/Experts inside
        for d in "$HOME/.wine/drive_c/users"/*/AppData/Roaming/MetaQuotes/Terminal/*/MQL5; do
            if [[ -d "$d/Experts" ]]; then
                MQL5_DIR="$d"
                break
            fi
        done
    fi
fi

if [[ -z "$MQL5_DIR" || ! -d "$MQL5_DIR" ]]; then
    cat >&2 <<EOF
ERROR: could not locate the MQL5 directory.

Set it explicitly with:
  export SEA_MQL5_DIR="/path/to/MQL5"
  $0

The MQL5 directory is the parent of Experts/, Include/, Indicators/.
EOF
    exit 2
fi

# -----------------------------------------------------------------------------
# Locate the EA file
# -----------------------------------------------------------------------------

EA_FILE="${EA_FILE_OVERRIDE:-$DEFAULT_EA_FILE}"
EA_PATH="$MQL5_DIR/Experts/$EA_FILE"

if [[ ! -f "$EA_PATH" ]]; then
    # Maybe it's a relative path from CWD
    if [[ -f "$EA_FILE" ]]; then
        EA_PATH="$(realpath "$EA_FILE" 2>/dev/null || readlink -f "$EA_FILE" 2>/dev/null || echo "$EA_FILE")"
    else
        echo "ERROR: EA file not found at $EA_PATH" >&2
        echo "Set with --file <relative-path-from-MQL5/Experts>  or  export SEA_EA_FILE=<...>" >&2
        exit 2
    fi
fi

# -----------------------------------------------------------------------------
# Convert Unix paths to Wine/Windows paths via winepath
# -----------------------------------------------------------------------------

to_win() {
    if command -v winepath >/dev/null 2>&1; then
        winepath -w "$1" 2>/dev/null
    else
        # Fallback: best-effort path translation for the common case
        # ~/.wine/drive_c/foo/bar  →  C:\foo\bar
        local p="$1"
        p="${p/$HOME\/.wine\/drive_c/C:}"
        p="${p//\//\\}"
        echo "$p"
    fi
}

EA_PATH_WIN="$(to_win "$EA_PATH")"
MQL5_DIR_WIN="$(to_win "$MQL5_DIR")"

# -----------------------------------------------------------------------------
# Set up the log file
# -----------------------------------------------------------------------------

mkdir -p "$LOG_DIR"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
TAG="${STEP_TAG:-build}"
LOG_FILE="$LOG_DIR/compile_${TAG}_${TIMESTAMP}.log"
LOG_FILE_WIN="$(to_win "$LOG_FILE")"

# Symlink the latest run for --diff-prev
LATEST_LINK="$LOG_DIR/latest.log"
PREV_LINK="$LOG_DIR/previous.log"

# -----------------------------------------------------------------------------
# Run the compile
# -----------------------------------------------------------------------------

CMD_ARGS=(
    "/compile:$EA_PATH_WIN"
    "/inc:$MQL5_DIR_WIN"
    "/log:$LOG_FILE_WIN"
)
[[ $SYNTAX_ONLY -eq 1 ]] && CMD_ARGS+=("/s")

echo "─── compile_check.sh ───────────────────────────────────────────────"
echo "  metaeditor: $METAEDITOR"
echo "  MQL5 dir:   $MQL5_DIR"
echo "  EA file:    $EA_PATH"
echo "  log file:   $LOG_FILE"
echo "  flags:      ${CMD_ARGS[*]}"
[[ -n "$STEP_TAG" ]] && echo "  step tag:   $STEP_TAG"
echo "────────────────────────────────────────────────────────────────────"

# MetaEditor sets ERRORLEVEL = 1 on success and 0 on failure (yes, inverted).
# Some Wine versions don't propagate ERRORLEVEL faithfully — we also parse
# the log file as the source of truth.
wine "$METAEDITOR" "${CMD_ARGS[@]}" >/dev/null 2>&1
RC=$?

# -----------------------------------------------------------------------------
# Parse the log
# -----------------------------------------------------------------------------

if [[ ! -f "$LOG_FILE" ]]; then
    echo "ERROR: MetaEditor produced no log file at $LOG_FILE" >&2
    echo "       This usually means the EA path or MQL5 dir is wrong." >&2
    echo "       Wine exit code: $RC" >&2
    exit 2
fi

# MetaEditor logs are UTF-16 LE on Windows. Convert to UTF-8 for grep.
LOG_UTF8="${LOG_FILE}.utf8"
if file "$LOG_FILE" 2>/dev/null | grep -q "UTF-16"; then
    iconv -f UTF-16LE -t UTF-8 "$LOG_FILE" 2>/dev/null > "$LOG_UTF8" || cp "$LOG_FILE" "$LOG_UTF8"
else
    cp "$LOG_FILE" "$LOG_UTF8"
fi

# Strip BOM if present
sed -i.bak '1s/^\xef\xbb\xbf//' "$LOG_UTF8" 2>/dev/null
rm -f "$LOG_UTF8.bak" 2>/dev/null

# Pull the summary line. MetaEditor writes lines like:
#     "Result   0 errors, 0 warnings"   (varies; sometimes "Errors 0 ...")
ERRORS=$(grep -c -E "^.*: error " "$LOG_UTF8" 2>/dev/null || echo 0)
WARNINGS=$(grep -c -E "^.*: warning " "$LOG_UTF8" 2>/dev/null || echo 0)

# Some MetaEditor builds put the summary in different formats, so fall back
# to parsing the "Result" / "errors" lines if grep -c found nothing.
if [[ "$ERRORS" -eq 0 && "$WARNINGS" -eq 0 ]]; then
    SUMMARY=$(grep -E "errors?, [0-9]+ warning" "$LOG_UTF8" | tail -1 || true)
    if [[ -n "$SUMMARY" ]]; then
        ERRORS=$(echo "$SUMMARY"   | grep -oE "[0-9]+ errors?"   | head -1 | grep -oE "[0-9]+" || echo 0)
        WARNINGS=$(echo "$SUMMARY" | grep -oE "[0-9]+ warnings?" | head -1 | grep -oE "[0-9]+" || echo 0)
    fi
fi

ERRORS=${ERRORS:-0}
WARNINGS=${WARNINGS:-0}

# -----------------------------------------------------------------------------
# Update latest/previous symlinks for --diff-prev
# -----------------------------------------------------------------------------

if [[ -L "$LATEST_LINK" || -f "$LATEST_LINK" ]]; then
    [[ -L "$PREV_LINK" || -f "$PREV_LINK" ]] && rm -f "$PREV_LINK"
    mv "$LATEST_LINK" "$PREV_LINK" 2>/dev/null || true
fi
ln -sf "$LOG_UTF8" "$LATEST_LINK"

# -----------------------------------------------------------------------------
# Print the report
# -----------------------------------------------------------------------------

echo
echo "Compile result:"
echo "  Errors:   $ERRORS"
echo "  Warnings: $WARNINGS"
echo

if [[ "$ERRORS" -gt 0 ]]; then
    echo "─── First 20 error/warning lines ───────────────────────────────────"
    grep -E "(error|warning) " "$LOG_UTF8" | head -20 | sed 's/^/  /'
    echo "────────────────────────────────────────────────────────────────────"
    echo "Full log: $LOG_UTF8"
    exit 1
fi

if [[ $DIFF_PREV -eq 1 && -f "$PREV_LINK" ]]; then
    PREV_ERR=$(grep -c -E "^.*: error "   "$PREV_LINK" 2>/dev/null || echo 0)
    PREV_WARN=$(grep -c -E "^.*: warning " "$PREV_LINK" 2>/dev/null || echo 0)
    echo "─── Diff vs previous run ───────────────────────────────────────────"
    echo "  Errors:   $PREV_ERR → $ERRORS  (Δ $((ERRORS - PREV_ERR)))"
    echo "  Warnings: $PREV_WARN → $WARNINGS  (Δ $((WARNINGS - PREV_WARN)))"
    if [[ "$WARNINGS" -gt "$PREV_WARN" ]]; then
        echo
        echo "  NEW warnings introduced by this step:"
        diff <(grep -E "warning " "$PREV_LINK" 2>/dev/null | sort -u) \
             <(grep -E "warning " "$LOG_UTF8" 2>/dev/null | sort -u) \
             | grep "^>" | sed 's/^> /    /'
    fi
    echo "────────────────────────────────────────────────────────────────────"
fi

if [[ "$STRICT" -eq 1 && "$WARNINGS" -gt 0 ]]; then
    echo "STRICT mode: $WARNINGS warnings present, exiting non-zero."
    exit 1
fi

echo "✓ Compile OK"
exit 0
