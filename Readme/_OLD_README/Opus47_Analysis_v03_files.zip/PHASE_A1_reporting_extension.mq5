// ============================================================================
//  PHASE A.1 — Reporting extension for the new pre-filter quality gates
//  Adds per-gate rejection counters to SEA_SignalEngine and a new report
//  section "1b. PRE-FILTER QUALITY GATES" that prints alongside the existing
//  "1. NON-DIRECTIONAL GATES" block in OnDeinit().
//
//  Why this matters:
//    Today every Phase A pre-filter rejection (EMA_OVEREXT, DPI_DECEL, plus
//    the new PHASE_AGE / HTF_BLOCKED / VETO_OPEN_DELAY / VETO_BC_STALE /
//    VETO_SPREAD_MEDIAN gates) is collapsed into a single `m_reject_filter`
//    counter. That makes it impossible to see WHICH new gate is doing the
//    work — or, more importantly, which one is over-rejecting and needs
//    its threshold dialed back via Phase B inputs.
//
//  Design:
//    - One new int field per gate in SRejectionStats. Same naming scheme
//      as existing fields (`rejected_<gate>` + `passed_<gate>`).
//    - Increment alongside the existing m_reject_filter++ at each gate's
//      rejection site (5 + 2 = 7 increment lines added).
//    - One new "passed" increment site at the end of EvaluateTS for bars
//      that reach signal confirmation (so the existing PrintGateStat helper
//      can compute pass% just like it does for spread/time/news).
//    - One new report section that calls PrintGateStat for each gate.
//    - Extension to PrintRejectionStatistics so the new gates appear in
//      the "TOP REJECTION REASONS" sorted list.
//
//  All changes are additive. Existing fields and call sites are untouched,
//  so any other preset (RRM, FPM, MA, CUSTOM, TEST) sees zeros for the new
//  counters and prints "OFF / -" for the new section.
// ============================================================================


// -----------------------------------------------------------------------------
//  STEP 1 — Extend SRejectionStats in SEA_SignalEngine.mqh (line ~98)
//           Add these field pairs at the end of the struct, before the
//           closing `int signals_confirmed;` line.
// -----------------------------------------------------------------------------

   // ── PHASE A.1: Pre-filter quality gates (TS=1 hardening) ──────────────
   int passed_emafan,     rejected_emafan;     // EMA fan overextension
   int passed_dpi_decel,  rejected_dpi_decel;  // DPI histogram deceleration
   int passed_phase_age,  rejected_phase_age;  // MinPhaseConfirmBars not met
   int passed_htf_align,  rejected_htf_align;  // HTF EMA slope disagrees with bias

   // ── PHASE A.1: TE-side gates (read by SEA_TradeExecutor) ──────────────
   int passed_te_open_delay,    rejected_te_open_delay;
   int passed_te_bc_recheck,    rejected_te_bc_recheck;
   int passed_te_spread_median, rejected_te_spread_median;


// -----------------------------------------------------------------------------
//  STEP 2 — Increment "rejected_*" at each pre-filter rejection site
//           Each replacement is a 1-line addition next to the existing
//           `m_reject_filter++;` line. No logic change.
// -----------------------------------------------------------------------------

// At SEA_SignalEngine.mqh line ~4773 (EMA_FAN rejection):
//   FIND:
//                m_diag_last_reason = "EMA_OVEREXT";
//                m_reject_filter++;
//   REPLACE WITH:
                m_diag_last_reason = "EMA_OVEREXT";
                m_reject_filter++;
                m_stats.rejected_emafan++;       // PHASE A.1


// At SEA_SignalEngine.mqh line ~4816 (DPI_DECEL rejection):
//   FIND:
//                m_diag_last_reason = "DPI_DECEL";
//                m_reject_filter++;
//   REPLACE WITH:
                m_diag_last_reason = "DPI_DECEL";
                m_reject_filter++;
                m_stats.rejected_dpi_decel++;    // PHASE A.1


// -----------------------------------------------------------------------------
//  STEP 3 — Add a NEW phase-age gate and HTF-alignment gate next to the
//           existing pre-filters. Both fire BEFORE EvaluateL (cheap guards).
//
//           Place this block immediately AFTER the DPI_DECEL pre-filter
//           (current line ~4828 in SEA_SignalEngine.mqh) and BEFORE the
//           "// ── L: Layer ──" comment at line 4830.
// -----------------------------------------------------------------------------

      // ══════════════════════════════════════════════════════════════════
      // PRE-FILTER (PHASE A.1): Phase-age confirmation
      // Reject when MinPhaseConfirmBars > 0 and the current phase has not
      // persisted for at least that many bars. Catches single-bar TM
      // flickers (Pattern D in 100-trades analysis) without requiring a
      // change to the EvaluateP() return contract.
      // ══════════════════════════════════════════════════════════════════
      if(m_settings.MinPhaseConfirmBars > 0 &&
         m_diag_phase_confirm_bars < m_settings.MinPhaseConfirmBars)
      {
         if(m_settings.DebugFlow)
            PrintFormat("[TS_PREFILTER] PHASE_AGE: bars=%d < required=%d → TS=0",
                        m_diag_phase_confirm_bars, m_settings.MinPhaseConfirmBars);
         m_diag_last_reason = "PHASE_AGE";
         m_reject_filter++;
         m_stats.rejected_phase_age++;
         if(!full_eval) {
            m_ts_status_string = StringFormat("B[%s] | I[%s] | F[%s]", m_eval_str_B, m_eval_str_I, m_eval_str_F);
            UpdateTelemetry(0);
            FlushOrClearDebugBuffer(0);
            RestoreForcedDebug();
            return 0;
         }
         if(m_eval_first_failure == "") m_eval_first_failure = "PHASE_AGE";
         m_eval_any_failure = true;
      }

      // ══════════════════════════════════════════════════════════════════
      // PRE-FILTER (PHASE A.1): HTF alignment
      // Reject when UseHTF=true and the higher-timeframe EMA slope at
      // shift=0 disagrees with the entry bias. Catches Pattern C trades
      // like #075 (USDJPY M5 LONG into the H1/H4 down-leg).
      //
      // Implementation note: GetHtfBias() is a small helper added below
      // (Step 4). It returns +1/-1/0 by reading h_htf_ema and comparing
      // EMA(0) vs EMA(N). Returns 0 (neutral, pass) on data unavailability.
      // ══════════════════════════════════════════════════════════════════
      if(m_settings.UseHTF && h_htf_ema != INVALID_HANDLE)
      {
         int htf_bias = GetHtfBias();
         if(htf_bias != 0 && htf_bias != B)
         {
            if(m_settings.DebugFlow)
               PrintFormat("[TS_PREFILTER] HTF_BLOCKED: htf=%+d vs bias=%+d → TS=0",
                           htf_bias, B);
            m_diag_last_reason = "HTF_BLOCKED";
            m_reject_filter++;
            m_stats.rejected_htf_align++;
            if(!full_eval) {
               m_ts_status_string = StringFormat("B[%s] | I[%s] | F[%s]", m_eval_str_B, m_eval_str_I, m_eval_str_F);
               UpdateTelemetry(0);
               FlushOrClearDebugBuffer(0);
               RestoreForcedDebug();
               return 0;
            }
            if(m_eval_first_failure == "") m_eval_first_failure = "HTF_BLOCKED";
            m_eval_any_failure = true;
         }
         else if(htf_bias != 0)
         {
            m_stats.passed_htf_align++;
         }
      }

      // (After all four pre-filters pass, increment the matching passed_*
      //  counters before falling into EvaluateL. We only increment the
      //  pass counter when the gate was actually evaluated — not when its
      //  enable flag is off — so PrintGateStat shows accurate "Pass%" only
      //  among bars where the gate was active.)
      if(m_settings.EmaFanFilterEnabled && m_settings.EmaFanMaxTotalPips > 0.0)
         m_stats.passed_emafan++;
      if(m_settings.DpiDecelFilterEnabled && m_settings.Ind_Dpi_Enabled)
         m_stats.passed_dpi_decel++;
      if(m_settings.MinPhaseConfirmBars > 0)
         m_stats.passed_phase_age++;


// -----------------------------------------------------------------------------
//  STEP 4 — Add the GetHtfBias() helper to SEA_SignalEngine class.
//           Place it next to the other small helpers (e.g. near GetMAVal).
// -----------------------------------------------------------------------------

   // ─────────────────────────────────────────────────────────────────────
   // HTF bias from the higher-timeframe EMA (h_htf_ema must be valid).
   // Returns +1 if HTF EMA is rising, -1 if falling, 0 if flat / no data.
   // The "rising/falling" check uses a 3-bar lookback to filter noise.
   // ─────────────────────────────────────────────────────────────────────
   int GetHtfBias()
   {
      if(h_htf_ema == INVALID_HANDLE) return 0;
      double e0[3];
      if(CopyBuffer(h_htf_ema, 0, 0, 3, e0) != 3) return 0;
      // e0[0] = current bar; e0[2] = 2 bars ago
      double diff = e0[0] - e0[2];
      double pip  = GlobalPipSize(m_symbol);
      if(pip <= 0.0) return 0;
      // Require at least 0.5 pip of slope per bar to count as directional.
      // Below that, treat as flat / no signal.
      double slope_pips_per_bar = (diff / pip) / 2.0;
      if(slope_pips_per_bar >  0.5) return +1;
      if(slope_pips_per_bar < -0.5) return -1;
      return 0;
   }


// -----------------------------------------------------------------------------
//  STEP 5 — Extend PrintEnhancedStatistics() to include section "1b".
//           Insert this block in SEA_SignalEngine.mqh between the existing
//           section 1 (NON-DIRECTIONAL GATES, line ~2497) and section 2
//           (BIAS & LAYER DETECTION, line ~2499).
// -----------------------------------------------------------------------------

      Print("");
      Print("================================================================");
      Print("1b. PRE-FILTER QUALITY GATES (Phase A.1 — TS=1 hardening)");
      Print("================================================================");
      PrintFormat("%-18s %-8s %7s %7s %7s   %s", "Gate", "Status", "Passed", "Failed", "Pass%", "Impact");
      Print("----------------------------------------------------------------");
      PrintGateStat("EMA Fan",
                    m_settings.EmaFanFilterEnabled,
                    m_stats.passed_emafan,
                    m_stats.rejected_emafan,
                    m_settings.EmaFanFilterEnabled
                       ? StringFormat("%.1f pips max", m_settings.EmaFanMaxTotalPips)
                       : "(disabled)");
      PrintGateStat("DPI Decel",
                    (m_settings.DpiDecelFilterEnabled && m_settings.Ind_Dpi_Enabled),
                    m_stats.passed_dpi_decel,
                    m_stats.rejected_dpi_decel,
                    (m_settings.DpiDecelFilterEnabled && m_settings.Ind_Dpi_Enabled)
                       ? "histogram shrinking"
                       : (!m_settings.Ind_Dpi_Enabled ? "(DPI off)" : "(disabled)"));
      PrintGateStat("Phase Age",
                    (m_settings.MinPhaseConfirmBars > 0),
                    m_stats.passed_phase_age,
                    m_stats.rejected_phase_age,
                    (m_settings.MinPhaseConfirmBars > 0)
                       ? StringFormat(">=%d bars", m_settings.MinPhaseConfirmBars)
                       : "(disabled)");
      PrintGateStat("HTF Align",
                    m_settings.UseHTF,
                    m_stats.passed_htf_align,
                    m_stats.rejected_htf_align,
                    m_settings.UseHTF
                       ? StringFormat("%s EMA%d slope", EnumToString(m_settings.HtfPeriod), m_settings.P_HtfEma)
                       : "(disabled)");
      Print("----------------------------------------------------------------");
      PrintFormat("Pre-filter blocks: %d bars",
                  m_stats.rejected_emafan + m_stats.rejected_dpi_decel +
                  m_stats.rejected_phase_age + m_stats.rejected_htf_align);


// -----------------------------------------------------------------------------
//  STEP 6 — Extend PrintRejectionStatistics() so the new gates appear in
//           the sorted "TOP REJECTION REASONS" list.
//
//           The struct array `reasons[27]` needs to be resized to `[34]` (or
//           larger) and these seven reasons appended before the bubble sort.
//           Place these inside PrintRejectionStatistics, after the existing
//           `reasons[idx].name = "DPI";` block (line ~2442).
// -----------------------------------------------------------------------------

      reasons[idx].name = "EMA Overext";
      reasons[idx].count = m_stats.rejected_emafan;
      reasons[idx++].pct = m_stats.rejected_emafan * 100.0 / m_stats.total_bars;

      reasons[idx].name = "DPI Decel";
      reasons[idx].count = m_stats.rejected_dpi_decel;
      reasons[idx++].pct = m_stats.rejected_dpi_decel * 100.0 / m_stats.total_bars;

      reasons[idx].name = "Phase Age";
      reasons[idx].count = m_stats.rejected_phase_age;
      reasons[idx++].pct = m_stats.rejected_phase_age * 100.0 / m_stats.total_bars;

      reasons[idx].name = "HTF Block";
      reasons[idx].count = m_stats.rejected_htf_align;
      reasons[idx++].pct = m_stats.rejected_htf_align * 100.0 / m_stats.total_bars;

      reasons[idx].name = "TE Open Delay";
      reasons[idx].count = m_stats.rejected_te_open_delay;
      reasons[idx++].pct = m_stats.rejected_te_open_delay * 100.0 / m_stats.total_bars;

      reasons[idx].name = "TE BC Stale";
      reasons[idx].count = m_stats.rejected_te_bc_recheck;
      reasons[idx++].pct = m_stats.rejected_te_bc_recheck * 100.0 / m_stats.total_bars;

      reasons[idx].name = "TE Spread Median";
      reasons[idx].count = m_stats.rejected_te_spread_median;
      reasons[idx++].pct = m_stats.rejected_te_spread_median * 100.0 / m_stats.total_bars;


// -----------------------------------------------------------------------------
//  STEP 7 — TE-side counter increments (in SEA_TradeExecutor.mqh)
//
//           The TE-side stats (open_delay, bc_recheck, spread_median) live
//           on the SignalEngine's m_stats but are incremented from the
//           TradeExecutor. Two options:
//
//           (A) Add a public setter on CSignalEngine and call it from
//               EvaluateTE — minimal coupling, but requires you to wire
//               an engine reference to the executor.
//
//           (B) Mirror the counters on the executor and have the existing
//               SimpleEA OnDeinit() handler aggregate both before printing.
//
//           Option (B) is the smaller change. The executor already tracks
//           m_spread_block_bars; adding three int counters next to it
//           costs zero coupling. SimpleEA_v1-03.mq5's OnDeinit can read
//           them via getters and add them into the engine's m_stats just
//           before PrintEnhancedStatistics() runs.
//
//           Drop these setters into CSignalEngine (public section):
// -----------------------------------------------------------------------------

   // ── PHASE A.1: aggregate TE-side counters into m_stats before reporting ─
   void AddTeStats(int rej_open_delay, int rej_bc_recheck, int rej_spread_median,
                   int pass_open_delay, int pass_bc_recheck, int pass_spread_median)
   {
      m_stats.rejected_te_open_delay     += rej_open_delay;
      m_stats.rejected_te_bc_recheck     += rej_bc_recheck;
      m_stats.rejected_te_spread_median  += rej_spread_median;
      m_stats.passed_te_open_delay       += pass_open_delay;
      m_stats.passed_te_bc_recheck       += pass_bc_recheck;
      m_stats.passed_te_spread_median    += pass_spread_median;
   }


// -----------------------------------------------------------------------------
//  STEP 8 — In SEA_TradeExecutor.mqh, declare matching counters and getters.
//           Place near the existing m_spread_block_bars declaration.
// -----------------------------------------------------------------------------

   // ── PHASE A.1: TE-side rejection counters ─────────────────────────────
   int m_te_rej_open_delay;
   int m_te_rej_bc_recheck;
   int m_te_rej_spread_median;
   int m_te_pass_open_delay;
   int m_te_pass_bc_recheck;
   int m_te_pass_spread_median;

   // Public getters (used by SimpleEA OnDeinit to bridge stats into engine)
public:
   int RejOpenDelay()     const { return m_te_rej_open_delay;     }
   int RejBCRecheck()     const { return m_te_rej_bc_recheck;     }
   int RejSpreadMedian()  const { return m_te_rej_spread_median;  }
   int PassOpenDelay()    const { return m_te_pass_open_delay;    }
   int PassBCRecheck()    const { return m_te_pass_bc_recheck;    }
   int PassSpreadMedian() const { return m_te_pass_spread_median; }


// -----------------------------------------------------------------------------
//  STEP 9 — Increment TE-side counters at each Phase B veto site
//           (these go inside the three PHASE B GATE blocks in EvaluateTE,
//           the file PHASE_B_inputs_and_TE.mq5 explains where each block
//           lives). Add ONE increment per veto site:
// -----------------------------------------------------------------------------

// In PHASE B GATE 1 (open delay), after `m_te_veto_reason = "VETO_OPEN_DELAY";`:
            m_te_rej_open_delay++;

// In PHASE B GATE 2 (BC recheck), after `m_te_veto_reason = "VETO_BC_STALE";`:
            m_te_rej_bc_recheck++;

// In PHASE B GATE 3 (spread median, inside EvaluateF when median > MaxSpread):
//   Add a separate veto reason, e.g. "VETO_SPREAD_MEDIAN", and:
            m_te_rej_spread_median++;

// At the END of EvaluateTE() — just before `return 1;` on the success path —
// increment all three "passed" counters for any gate that was active:
      if(m_settings.TE_OpenDelaySeconds > 0)  m_te_pass_open_delay++;
      if(m_settings.TE_RecheckBarClose)        m_te_pass_bc_recheck++;
      if(m_settings.TE_SpreadMedianTicks > 0)  m_te_pass_spread_median++;


// -----------------------------------------------------------------------------
//  STEP 10 — Wire the bridge in SimpleEA_v1-03.mq5 OnDeinit().
//            One line, before any reporting calls. Assumes the engine is
//            named `g_engine` and the executor is `g_executor` — adjust to
//            the actual variable names in the EA.
// -----------------------------------------------------------------------------

void OnDeinit(const int reason)
{
   // ── PHASE A.1: aggregate TE-side counters into engine stats ──
   g_engine.AddTeStats(
      g_executor.RejOpenDelay(),    g_executor.RejBCRecheck(),    g_executor.RejSpreadMedian(),
      g_executor.PassOpenDelay(),   g_executor.PassBCRecheck(),   g_executor.PassSpreadMedian()
   );

   // existing reporting calls follow unchanged
   g_engine.PrintEnhancedStatistics();
   g_engine.PrintRejectionStatistics();
   // ...
}


// =============================================================================
//  EXPECTED LOG OUTPUT after applying steps 1-10
// =============================================================================
//
//  (added between existing sections 1 and 2)
//
//  ================================================================
//  1b. PRE-FILTER QUALITY GATES (Phase A.1 — TS=1 hardening)
//  ================================================================
//  Gate               Status    Passed  Failed   Pass%   Impact
//  ----------------------------------------------------------------
//  EMA Fan            ON          1247     183   87.2%   12.8% blocked  (60.0 pips max)
//  DPI Decel          ON          1052     378   73.6%   26.4% BLOCKED  (histogram shrinking)
//  Phase Age          ON           892     538   62.4%   37.6% BLOCKED  (>=2 bars)
//  HTF Align          ON           721      94   88.5%   No blocks     (PERIOD_H4 EMA89 slope)
//  ----------------------------------------------------------------
//  Pre-filter blocks: 1193 bars
//
//  (existing TOP REJECTION REASONS now includes the new gates,
//   sorted alongside the existing ones by absolute count)
//
//   1. Phase=UNORDERED       :  4521 bars (38.2%)
//   2. Phase Age             :   538 bars ( 4.5%)   ← NEW
//   3. EMA Overext           :   183 bars ( 1.5%)   ← NEW
//   4. DPI Decel             :   378 bars ( 3.2%)   ← NEW
//   ...
//
//  This per-gate breakdown is the single biggest optimization unlock:
//  if "Phase Age" rejects 37%+ on M5, it's too tight — dial down via
//  Phase B input Inp_RRM_ORG_PhaseConfirmM5 from 1 to 0. If "EMA Fan"
//  rejects <5%, the TF threshold is too loose — tighten it.
