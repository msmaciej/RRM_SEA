#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_phase_a_lift.py
=======================

Compute the per-gate lift of the PRESET_RRM_ORG Phase A hardening from the
filled `100-trades_labels.csv`.

Designed to run two ways:
  • Standalone:   `python analyze_phase_a_lift.py [path/to/labels.csv]`
  • As a notebook: each `# %%` block is a Jupyter/VS Code cell (Jupytext format)

Outputs printed to stdout:
  1. Coverage / data-quality summary
  2. Baseline winrate, profit-factor, expectancy
  3. Per-gate "would-have-rejected" counts and the resulting filtered
     winrate, PF, expectancy, and LIFT vs. baseline
  4. Combined "Phase A applied" winrate (any gate fires → reject)
  5. Failure-pattern × outcome contingency table
  6. Per-timeframe and per-symbol breakdowns

No third-party dependencies beyond pandas + (optional) tabulate. If pandas
is missing, the script falls back to a pure-stdlib reader + manual stats.

The script does NOT mutate the CSV. It is read-only.
"""

from __future__ import annotations

import sys
import csv
import math
import os
from pathlib import Path
from collections import Counter, defaultdict


# -----------------------------------------------------------------------------
# %% Cell 1 — Configuration
# -----------------------------------------------------------------------------

# Default path: assumes the script is run from the same dir as the CSV
DEFAULT_CSV = "100-trades_labels.csv"

# Phase A gate thresholds — must match the values in
# preset_rrm_org_PHASE_A.patch (or whatever live values you're testing).
# Edit these before re-running to A/B alternate threshold sets.
EMA_FAN_MAX_PIPS = {
    "M1":  25.0, "M5":  25.0,
    "M15": 40.0, "M30": 40.0,
    "H1":  60.0,
    "H4":  100.0,
    "D1":  180.0, "W1": 180.0,
}
PHASE_AGE_MIN_BARS = {
    "M1":  1, "M5":  1,
    "M15": 2, "M30": 2,
    "H1":  3, "H4":  3, "D1":  3, "W1":  3,
}
# Outcome mapping (case-insensitive)
OUTCOME_WIN  = {"win", "winner", "w"}
OUTCOME_LOSS = {"loss", "loser", "l", "lose"}
OUTCOME_BE   = {"be", "breakeven", "break-even"}


# -----------------------------------------------------------------------------
# %% Cell 2 — Loaders
# -----------------------------------------------------------------------------

def load_csv(path: Path) -> list[dict]:
    """Read the labels CSV. Returns list of row dicts with stripped strings."""
    with path.open() as f:
        reader = csv.DictReader(f)
        rows = []
        for r in reader:
            rows.append({k: (v.strip() if isinstance(v, str) else v) for k, v in r.items()})
    return rows


def coerce_float(v: str | None) -> float | None:
    if v is None or v == "": return None
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


def coerce_int(v: str | None) -> int | None:
    f = coerce_float(v)
    return int(f) if f is not None else None


def normalize_outcome(v: str | None) -> str | None:
    if not v: return None
    v = v.lower().strip()
    if v in OUTCOME_WIN:  return "WIN"
    if v in OUTCOME_LOSS: return "LOSS"
    if v in OUTCOME_BE:   return "BE"
    return None  # unknown / OPEN / blank


def coverage(rows: list[dict]) -> dict:
    """Report which columns are filled vs. blank across the dataset."""
    total = len(rows)
    out = {}
    for col in rows[0].keys():
        filled = sum(1 for r in rows if r.get(col, "") not in ("", None))
        out[col] = (filled, total, filled / total if total else 0.0)
    return out


# -----------------------------------------------------------------------------
# %% Cell 3 — Stats helpers
# -----------------------------------------------------------------------------

def winrate(rows: list[dict]) -> tuple[float, int, int]:
    """Returns (winrate, n_wins, n_decided). 'decided' = WIN+LOSS only."""
    wins   = sum(1 for r in rows if normalize_outcome(r.get("outcome")) == "WIN")
    losses = sum(1 for r in rows if normalize_outcome(r.get("outcome")) == "LOSS")
    n = wins + losses
    return (wins / n if n else float("nan"), wins, n)


def profit_factor(rows: list[dict]) -> float:
    """PF = sum(wins R) / sum(|losses R|)."""
    gross_win = 0.0
    gross_loss = 0.0
    for r in rows:
        rm = coerce_float(r.get("r_multiple"))
        if rm is None: continue
        if rm > 0: gross_win += rm
        elif rm < 0: gross_loss += -rm
    if gross_loss == 0:
        return float("inf") if gross_win > 0 else float("nan")
    return gross_win / gross_loss


def expectancy(rows: list[dict]) -> float:
    """Average R per trade across decided trades."""
    rs = [coerce_float(r.get("r_multiple")) for r in rows]
    rs = [x for x in rs if x is not None]
    return sum(rs) / len(rs) if rs else float("nan")


def fmt_pct(x: float) -> str:
    return f"{x*100:5.1f}%" if not math.isnan(x) else "  n/a"


def fmt_signed(x: float, suffix="") -> str:
    return f"{x:+.2f}{suffix}" if not math.isnan(x) and not math.isinf(x) else "n/a"


# -----------------------------------------------------------------------------
# %% Cell 4 — Gate predicates (one per Phase A gate)
# -----------------------------------------------------------------------------
#
# Each gate is a function `would_reject(row) -> bool`. They use ONLY label
# columns from the CSV — no live indicator computation needed. Add or
# tighten predicates here when you want to A/B alternate gate logic.
#

def gate_emafan(row: dict) -> bool:
    """EMA Fan: reject when fan_pips > tf_threshold AND fan was expanding."""
    tf = (row.get("timeframe") or "").upper()
    fan = coerce_float(row.get("fan_pips_at_entry"))
    expanding = coerce_int(row.get("fan_was_expanding"))
    if fan is None or expanding is None or tf not in EMA_FAN_MAX_PIPS:
        return False  # no data → don't reject (conservative)
    return (fan > EMA_FAN_MAX_PIPS[tf]) and (expanding == 1)


def gate_dpi_decel(row: dict) -> bool:
    """DPI Decel: reject when histogram aligned with bias is shrinking."""
    decel = coerce_int(row.get("dpi_decel_at_entry"))
    return decel == 1


def gate_phase_age(row: dict) -> bool:
    """Phase Age: reject when phase_age_bars < tf threshold."""
    tf = (row.get("timeframe") or "").upper()
    age = coerce_int(row.get("phase_age_bars"))
    if age is None or tf not in PHASE_AGE_MIN_BARS:
        return False
    return age < PHASE_AGE_MIN_BARS[tf]


def gate_htf_align(row: dict) -> bool:
    """HTF: reject when htf_aligned == 0."""
    align = coerce_int(row.get("htf_aligned"))
    return align == 0


GATES = {
    "EMA Fan":   gate_emafan,
    "DPI Decel": gate_dpi_decel,
    "Phase Age": gate_phase_age,
    "HTF Align": gate_htf_align,
}


# -----------------------------------------------------------------------------
# %% Cell 5 — Lift table
# -----------------------------------------------------------------------------

def gate_table(rows: list[dict]) -> list[dict]:
    """
    For each gate, compute:
      n_rejected    — trades where gate fires
      n_rej_decided — of those, how many had WIN/LOSS labels
      rej_winrate   — winrate of trades the gate REJECTS
                      (we WANT this to be LOW: the gate should kill losers)
      kept_winrate  — winrate of trades the gate KEEPS
      lift          — kept_winrate - baseline_winrate
      pf_kept       — profit factor among kept trades
      precision     — fraction of rejections that were actual losers
                      (high = gate is well-calibrated)
    """
    base_wr, _, _ = winrate(rows)
    base_pf       = profit_factor(rows)

    results = []
    for name, predicate in GATES.items():
        rejected = [r for r in rows if predicate(r)]
        kept     = [r for r in rows if not predicate(r)]
        n_rej    = len(rejected)
        rej_decided = [r for r in rejected if normalize_outcome(r.get("outcome")) in ("WIN","LOSS")]
        rej_losers  = sum(1 for r in rej_decided if normalize_outcome(r.get("outcome")) == "LOSS")

        rej_wr,  _, n_rej_dec = winrate(rejected)
        kept_wr, _, _         = winrate(kept)
        pf_kept = profit_factor(kept)

        precision = (rej_losers / n_rej_dec) if n_rej_dec else float("nan")
        lift      = (kept_wr - base_wr) if not math.isnan(kept_wr) and not math.isnan(base_wr) else float("nan")

        results.append({
            "gate": name,
            "n_rej": n_rej,
            "rej_decided": n_rej_dec,
            "rej_winrate": rej_wr,
            "kept_winrate": kept_wr,
            "lift_vs_base": lift,
            "pf_kept": pf_kept,
            "precision": precision,
        })

    return results


def combined_lift(rows: list[dict]) -> dict:
    """Phase A (any-gate-fires → reject) lift over baseline."""
    base_wr, _, _ = winrate(rows)
    base_pf       = profit_factor(rows)
    base_exp      = expectancy(rows)

    rejected = [r for r in rows if any(g(r) for g in GATES.values())]
    kept     = [r for r in rows if not any(g(r) for g in GATES.values())]
    kept_wr, _, _ = winrate(kept)
    kept_pf       = profit_factor(kept)
    kept_exp      = expectancy(kept)

    return {
        "n_total":  len(rows),
        "n_kept":   len(kept),
        "n_rejected": len(rejected),
        "base_winrate":  base_wr,
        "kept_winrate":  kept_wr,
        "winrate_lift":  (kept_wr - base_wr) if not math.isnan(kept_wr) else float("nan"),
        "base_pf":       base_pf,
        "kept_pf":       kept_pf,
        "base_expectancy": base_exp,
        "kept_expectancy": kept_exp,
    }


# -----------------------------------------------------------------------------
# %% Cell 6 — Group-by reports
# -----------------------------------------------------------------------------

def group_winrates(rows: list[dict], key: str) -> list[tuple[str, int, int, float]]:
    """Return [(group, n_decided, n_wins, winrate)] sorted by n descending."""
    bucket: dict[str, list[dict]] = defaultdict(list)
    for r in rows:
        k = (r.get(key) or "").strip() or "(blank)"
        bucket[k].append(r)
    out = []
    for k, rs in bucket.items():
        wr, wins, n = winrate(rs)
        out.append((k, n, wins, wr))
    out.sort(key=lambda x: -x[1])
    return out


def pattern_outcome_table(rows: list[dict]) -> list[list[str]]:
    """Failure pattern × outcome contingency."""
    patterns = ["", "B", "C", "D"]   # "" = no failure pattern (winner)
    outcomes = ["WIN", "LOSS", "BE", "(unknown)"]
    grid = {(p, o): 0 for p in patterns for o in outcomes}
    for r in rows:
        p = (r.get("failure_pattern") or "").strip().upper()
        if p not in patterns: p = ""
        o = normalize_outcome(r.get("outcome")) or "(unknown)"
        grid[(p, o)] += 1
    rows_out = [["pattern"] + outcomes + ["total"]]
    for p in patterns:
        line = [p or "(none/A)"]
        total = 0
        for o in outcomes:
            v = grid[(p, o)]
            line.append(str(v))
            total += v
        line.append(str(total))
        rows_out.append(line)
    return rows_out


# -----------------------------------------------------------------------------
# %% Cell 7 — Pretty-printing
# -----------------------------------------------------------------------------

def pad(s: str, w: int, right=False) -> str:
    s = str(s)
    return s.rjust(w) if right else s.ljust(w)


def print_section(title: str):
    print()
    print("=" * 72)
    print(title)
    print("=" * 72)


def print_table(headers: list[str], rows: list[list[str]], aligns: list[str] | None = None):
    if aligns is None:
        aligns = ["l"] * len(headers)
    widths = [max(len(headers[i]), max((len(r[i]) for r in rows), default=0)) for i in range(len(headers))]
    print("  ".join(pad(h, widths[i], aligns[i] == "r") for i, h in enumerate(headers)))
    print("  ".join("-" * w for w in widths))
    for r in rows:
        print("  ".join(pad(c, widths[i], aligns[i] == "r") for i, c in enumerate(r)))


# -----------------------------------------------------------------------------
# %% Cell 8 — Main
# -----------------------------------------------------------------------------

def main(csv_path: Path):
    if not csv_path.exists():
        print(f"ERROR: {csv_path} not found", file=sys.stderr)
        sys.exit(1)

    rows = load_csv(csv_path)
    print(f"Loaded {len(rows)} rows from {csv_path.name}")

    # ── 1. Coverage ────────────────────────────────────────────────────────
    print_section("1. DATA COVERAGE")
    cov = coverage(rows)
    critical_cols = [
        "symbol", "timeframe", "direction", "outcome", "r_multiple",
        "phase_at_entry", "fan_pips_at_entry", "fan_was_expanding",
        "dpi_decel_at_entry", "phase_age_bars", "htf_aligned",
        "failure_pattern",
    ]
    table = []
    for col in critical_cols:
        if col not in cov: continue
        filled, total, frac = cov[col]
        flag = "OK" if frac >= 0.8 else ("partial" if frac >= 0.3 else "MISSING")
        table.append([col, f"{filled}/{total}", f"{frac*100:5.1f}%", flag])
    print_table(["column", "filled", "fraction", "status"], table, ["l", "r", "r", "l"])

    decided = [r for r in rows if normalize_outcome(r.get("outcome")) in ("WIN","LOSS")]
    print(f"\nDecided trades (WIN+LOSS): {len(decided)} / {len(rows)}")
    if len(decided) < 20:
        print("⚠️  Fewer than 20 decided trades — gate-level winrates will be unstable.")
        print("    Fill out more `outcome` and `r_multiple` columns before trusting the lift numbers.")

    # ── 2. Baseline ───────────────────────────────────────────────────────
    print_section("2. BASELINE (no Phase A gates applied)")
    base_wr, base_wins, base_n = winrate(rows)
    base_pf  = profit_factor(rows)
    base_exp = expectancy(rows)
    print(f"  Decided trades:    {base_n}")
    print(f"  Wins / Losses:     {base_wins} / {base_n - base_wins}")
    print(f"  Winrate:           {fmt_pct(base_wr)}")
    print(f"  Profit factor:     {fmt_signed(base_pf)}")
    print(f"  Expectancy (R):    {fmt_signed(base_exp, ' R')}")

    # ── 3. Per-gate table ──────────────────────────────────────────────────
    print_section("3. PER-GATE LIFT (single gate vs. baseline)")
    gtab = gate_table(rows)
    headers = ["gate", "n_rej", "rej_dec", "rej_WR", "kept_WR", "lift", "kept_PF", "precision"]
    aligns  = ["l", "r", "r", "r", "r", "r", "r", "r"]
    table_rows = []
    for g in gtab:
        table_rows.append([
            g["gate"],
            str(g["n_rej"]),
            str(g["rej_decided"]),
            fmt_pct(g["rej_winrate"]),
            fmt_pct(g["kept_winrate"]),
            fmt_pct(g["lift_vs_base"]) if not math.isnan(g["lift_vs_base"]) else "n/a",
            fmt_signed(g["pf_kept"]),
            fmt_pct(g["precision"]),
        ])
    print_table(headers, table_rows, aligns)
    print()
    print("  Reading the table:")
    print("    rej_WR     = winrate among trades this gate rejects (LOWER = gate is killing losers ✓)")
    print("    kept_WR    = winrate among trades this gate keeps")
    print("    lift       = kept_WR − baseline_WR  (POSITIVE = gate adds quality)")
    print("    precision  = fraction of rejections that were actual losers (HIGHER = better-calibrated)")

    # ── 4. Combined Phase A ────────────────────────────────────────────────
    print_section("4. COMBINED PHASE A (any gate fires → reject)")
    c = combined_lift(rows)
    print(f"  Total trades:           {c['n_total']}")
    print(f"  Rejected by Phase A:    {c['n_rejected']} ({c['n_rejected']/c['n_total']*100:.1f}%)")
    print(f"  Kept after Phase A:     {c['n_kept']} ({c['n_kept']/c['n_total']*100:.1f}%)")
    print()
    print(f"  Baseline winrate:       {fmt_pct(c['base_winrate'])}")
    print(f"  Phase A winrate:        {fmt_pct(c['kept_winrate'])}")
    print(f"  Winrate lift:           {fmt_pct(c['winrate_lift'])}")
    print()
    print(f"  Baseline PF:            {fmt_signed(c['base_pf'])}")
    print(f"  Phase A PF:             {fmt_signed(c['kept_pf'])}")
    print()
    print(f"  Baseline expectancy:    {fmt_signed(c['base_expectancy'], ' R')}")
    print(f"  Phase A expectancy:     {fmt_signed(c['kept_expectancy'], ' R')}")

    # ── 5. Pattern × outcome ───────────────────────────────────────────────
    print_section("5. FAILURE PATTERN × OUTCOME")
    print("  (Pattern column from your visual analysis: B=EM-flicker C=overextended D=tangled,")
    print("   blank=Pattern A clean TM. This tells you which patterns Phase A SHOULD be killing.)")
    print()
    grid = pattern_outcome_table(rows)
    print_table(grid[0], grid[1:], ["l"] + ["r"] * (len(grid[0]) - 1))

    # ── 6. Per-TF and per-symbol ───────────────────────────────────────────
    print_section("6. WINRATE BY TIMEFRAME")
    by_tf = group_winrates(rows, "timeframe")
    print_table(["timeframe", "n_dec", "wins", "WR"],
                [[k, str(n), str(w), fmt_pct(wr)] for k, n, w, wr in by_tf],
                ["l", "r", "r", "r"])

    print_section("7. WINRATE BY SYMBOL")
    by_sym = group_winrates(rows, "symbol")
    print_table(["symbol", "n_dec", "wins", "WR"],
                [[k, str(n), str(w), fmt_pct(wr)] for k, n, w, wr in by_sym],
                ["l", "r", "r", "r"])

    # ── 8. Tuning hints ────────────────────────────────────────────────────
    print_section("8. TUNING HINTS")
    hints = []
    for g in gtab:
        if g["rej_decided"] == 0:
            hints.append(f"  • {g['gate']}: 0 decided rejections — fill more outcome labels or threshold may be too loose")
            continue
        # Precision low = gate over-rejects winners
        if not math.isnan(g["precision"]) and g["precision"] < 0.5:
            hints.append(f"  • {g['gate']}: precision={fmt_pct(g['precision'])} — gate rejects more winners than losers; LOOSEN threshold")
        # Lift negative = gate hurts
        if not math.isnan(g["lift_vs_base"]) and g["lift_vs_base"] < 0:
            hints.append(f"  • {g['gate']}: NEGATIVE lift {fmt_pct(g['lift_vs_base'])} — gate is harmful as configured; review predicate")
        # Few rejections = gate barely fires
        if g["n_rej"] < 3:
            hints.append(f"  • {g['gate']}: only {g['n_rej']} rejections out of {len(rows)} — threshold too loose to do useful work")
    if not hints:
        hints.append("  • All gates have positive lift, reasonable precision, and meaningful reject counts. Ship it.")
    for h in hints: print(h)

    print()
    print("Done. To A/B alternate thresholds:")
    print("  1. Edit EMA_FAN_MAX_PIPS or PHASE_AGE_MIN_BARS at top of this script")
    print("  2. Re-run. The same labeled CSV becomes the test bed for any gate config.")


# -----------------------------------------------------------------------------
# %% Cell 9 — Comparison mode (--baseline-csv)
# -----------------------------------------------------------------------------
#
# Two-CSV mode: compares trades from a backtest run BEFORE Phase A against
# trades from a backtest run AFTER Phase A on the SAME period and symbol set.
#
# What it reports:
#   • Trade-count delta:    how many trades Phase A removed (or added)
#   • Survivor analysis:    of the trades that survived in BOTH runs, did
#                           their outcomes change? (They shouldn't — same
#                           setup, same SL/TP. If outcomes differ, the
#                           backtests aren't comparable.)
#   • Removed-trade quality: of the trades present in baseline but NOT in
#                           Phase A, what fraction were losers? This is the
#                           single most direct measure of whether Phase A
#                           did its job.
#   • Aggregate metric deltas: winrate, PF, expectancy with confidence
#                           intervals on the deltas.
#
# Trade matching: trades are matched on (symbol, timeframe, entry_bar_time_utc,
# direction). If the user labeled the SAME 100 trades twice (one baseline,
# one Phase A), the match is straightforward. If the second CSV is from a
# fresh backtest (more trades, different IDs), matching is approximate.
#
# -----------------------------------------------------------------------------

def trade_key(row: dict) -> tuple:
    """Composite key used to match trades between two runs."""
    return (
        (row.get("symbol") or "").upper().strip(),
        (row.get("timeframe") or "").upper().strip(),
        (row.get("entry_bar_time_utc") or "").strip(),
        (row.get("direction") or "").upper().strip(),
    )


def index_trades(rows: list[dict]) -> dict[tuple, dict]:
    """Build a {key: row} index, keeping only rows with non-empty keys."""
    out = {}
    collisions = 0
    for r in rows:
        k = trade_key(r)
        if not all(k):  # any component blank → skip
            continue
        if k in out:
            collisions += 1
        out[k] = r
    if collisions:
        print(f"  ⚠️  {collisions} duplicate trade keys collapsed (kept last)")
    return out


def run_comparison(baseline_csv: Path, phasea_csv: Path):
    """Compare a baseline CSV (pre-Phase-A) against a Phase A CSV."""

    base_rows = load_csv(baseline_csv)
    a_rows    = load_csv(phasea_csv)
    print(f"Loaded baseline: {len(base_rows)} rows from {baseline_csv.name}")
    print(f"Loaded Phase A:  {len(a_rows)} rows from {phasea_csv.name}")

    base_idx = index_trades(base_rows)
    a_idx    = index_trades(a_rows)

    print(f"  Indexable in baseline: {len(base_idx)}")
    print(f"  Indexable in Phase A:  {len(a_idx)}")

    base_keys = set(base_idx.keys())
    a_keys    = set(a_idx.keys())
    survived  = base_keys & a_keys
    removed   = base_keys - a_keys
    added     = a_keys - base_keys

    # ── Section 1: trade-count delta ──────────────────────────────────────
    print_section("1. TRADE-COUNT DELTA")
    print(f"  Baseline trades:                  {len(base_idx):>5}")
    print(f"  Phase A trades:                   {len(a_idx):>5}")
    print(f"  Survived in both runs:            {len(survived):>5}")
    print(f"  REMOVED by Phase A (good?):       {len(removed):>5}")
    print(f"  ADDED in Phase A only (?):        {len(added):>5}")
    if added:
        print()
        print("  ⚠️  Phase A produced trades that weren't in baseline. This is unusual —")
        print("      Phase A should only REMOVE trades, never add new ones. Possible causes:")
        print("        • Different backtest periods or pairs in the two runs")
        print("        • A new gate is incorrectly producing entries (regression)")
        print("        • Trade-key columns inconsistent between the two CSVs")

    # ── Section 2: removed-trade quality (the headline number) ────────────
    print_section("2. REMOVED-TRADE QUALITY (did Phase A kill losers?)")
    if not removed:
        print("  No trades were removed. Either Phase A had no effect on this dataset,")
        print("  or the two CSVs cover different trade populations.")
    else:
        removed_rows = [base_idx[k] for k in removed]
        rem_wr, rem_wins, rem_n = winrate(removed_rows)
        rem_pf  = profit_factor(removed_rows)
        rem_exp = expectancy(removed_rows)
        # Compare to baseline overall winrate
        base_wr, _, _ = winrate(base_rows)
        # Precision-style metric: of the rejections, what % were losers?
        rem_losses = rem_n - rem_wins if not math.isnan(rem_wr) else 0
        precision = rem_losses / rem_n if rem_n > 0 else float("nan")

        print(f"  Trades removed by Phase A:        {len(removed)}")
        print(f"  Decided (WIN+LOSS):               {rem_n}")
        print(f"  Winrate among REMOVED:            {fmt_pct(rem_wr)}")
        print(f"  Baseline overall winrate:         {fmt_pct(base_wr)}")
        if not math.isnan(rem_wr) and not math.isnan(base_wr):
            delta = rem_wr - base_wr
            print(f"  Removed_WR − Baseline_WR:         {fmt_signed(delta * 100, '%')}")
            print(f"    (LARGE NEGATIVE = Phase A correctly killed below-average trades ✓)")
            print(f"    (POSITIVE       = Phase A removed winners — RECALIBRATE)")
        print(f"  Profit factor of REMOVED:         {fmt_signed(rem_pf)}")
        print(f"  Expectancy of REMOVED:            {fmt_signed(rem_exp, ' R')}")
        print(f"    (Negative expectancy on removed trades = Phase A is a net positive ✓)")
        print(f"  Precision (frac of rejects = losers): {fmt_pct(precision)}")

    # ── Section 3: survivor outcome consistency ───────────────────────────
    print_section("3. SURVIVOR OUTCOME CONSISTENCY")
    if not survived:
        print("  No surviving trades to compare.")
    else:
        same_outcome = 0
        different_outcome = 0
        no_outcome_change = 0
        examples = []
        for k in survived:
            b_oc = normalize_outcome(base_idx[k].get("outcome"))
            a_oc = normalize_outcome(a_idx[k].get("outcome"))
            if b_oc is None or a_oc is None:
                no_outcome_change += 1
            elif b_oc == a_oc:
                same_outcome += 1
            else:
                different_outcome += 1
                if len(examples) < 5:
                    examples.append((k, b_oc, a_oc))
        print(f"  Surviving trades:                 {len(survived)}")
        print(f"  Same outcome in both runs:        {same_outcome}")
        print(f"  Different outcome:                {different_outcome}")
        print(f"  Cannot compare (missing label):   {no_outcome_change}")
        if different_outcome:
            print()
            print("  ⚠️  Some surviving trades have DIFFERENT outcomes between runs.")
            print("      This shouldn't happen if Phase A only adds entry filters.")
            print("      Possible causes: different SL/TP modes between runs, different")
            print("      slippage modelling, different spread, broker data updates.")
            print()
            print("  Examples:")
            for (sym, tf, ts, dir_), b_oc, a_oc in examples:
                print(f"    {sym} {tf} {ts} {dir_}: baseline={b_oc} → phase_a={a_oc}")

    # ── Section 4: aggregate metric deltas ────────────────────────────────
    print_section("4. AGGREGATE METRICS")
    base_wr, base_wins, base_n = winrate(base_rows)
    a_wr,    a_wins,    a_n    = winrate(a_rows)
    base_pf  = profit_factor(base_rows)
    a_pf     = profit_factor(a_rows)
    base_exp = expectancy(base_rows)
    a_exp    = expectancy(a_rows)

    table = [
        ["Decided trades",  str(base_n),                       str(a_n),                    f"{a_n - base_n:+d}"],
        ["Wins",            str(base_wins),                    str(a_wins),                 f"{a_wins - base_wins:+d}"],
        ["Winrate",         fmt_pct(base_wr),                  fmt_pct(a_wr),
                            (fmt_signed((a_wr - base_wr)*100, "%") if not math.isnan(base_wr) and not math.isnan(a_wr) else "n/a")],
        ["Profit factor",   fmt_signed(base_pf),               fmt_signed(a_pf),
                            (fmt_signed(a_pf - base_pf) if not math.isnan(base_pf) and not math.isnan(a_pf) and not math.isinf(base_pf) and not math.isinf(a_pf) else "n/a")],
        ["Expectancy (R)",  fmt_signed(base_exp, " R"),        fmt_signed(a_exp, " R"),
                            (fmt_signed(a_exp - base_exp, " R") if not math.isnan(base_exp) and not math.isnan(a_exp) else "n/a")],
    ]
    print_table(["metric", "baseline", "phase_a", "delta"], table, ["l", "r", "r", "r"])

    # ── Section 5: comparison-mode verdict ────────────────────────────────
    print_section("5. VERDICT")
    verdicts = []
    if not removed:
        verdicts.append("  ◦ Phase A removed no trades. No A/B information available.")
    else:
        # Compute the key stats
        removed_rows = [base_idx[k] for k in removed]
        rem_wr, _, rem_n = winrate(removed_rows)
        if rem_n == 0:
            verdicts.append(
                "  ⚠ No outcome labels on removed trades — cannot judge whether the "
                "rejections were good. Label the `outcome` column on the baseline CSV "
                "for the trades that Phase A removed."
            )
        else:
            base_wr_overall, _, _ = winrate(base_rows)
            if not math.isnan(rem_wr) and not math.isnan(base_wr_overall):
                if rem_wr < base_wr_overall - 0.10:
                    verdicts.append(
                        f"  ✓ Phase A is removing trades with {fmt_pct(rem_wr)} winrate "
                        f"vs. baseline {fmt_pct(base_wr_overall)} overall — clear "
                        f"improvement on the rejection side."
                    )
                elif rem_wr > base_wr_overall + 0.05:
                    verdicts.append(
                        f"  ✗ Phase A is REMOVING WINNERS — rejected trades have "
                        f"{fmt_pct(rem_wr)} winrate, higher than baseline "
                        f"{fmt_pct(base_wr_overall)}. Recalibrate gate thresholds."
                    )
                else:
                    verdicts.append(
                        f"  ◦ Phase A's rejections are roughly average ({fmt_pct(rem_wr)} "
                        f"vs. baseline {fmt_pct(base_wr_overall)}). Net effect is small; "
                        f"check whether it's worth keeping Phase A on."
                    )

    # Aggregate verdict
    if not math.isnan(base_wr) and not math.isnan(a_wr):
        wr_delta = a_wr - base_wr
        if wr_delta > 0.05:
            verdicts.append(f"  ✓ Aggregate winrate up {fmt_signed(wr_delta * 100, '%')}.")
        elif wr_delta < -0.02:
            verdicts.append(f"  ✗ Aggregate winrate DOWN {fmt_signed(wr_delta * 100, '%')} — Phase A net-harmful here.")
        else:
            verdicts.append(f"  ◦ Aggregate winrate change negligible ({fmt_signed(wr_delta * 100, '%')}).")

    if not math.isnan(base_pf) and not math.isnan(a_pf) and not math.isinf(base_pf) and not math.isinf(a_pf):
        if a_pf > base_pf * 1.10:
            verdicts.append(f"  ✓ Profit factor improved {fmt_signed(base_pf)} → {fmt_signed(a_pf)} (>10%).")
        elif a_pf < base_pf * 0.90:
            verdicts.append(f"  ✗ Profit factor degraded {fmt_signed(base_pf)} → {fmt_signed(a_pf)}.")

    for v in verdicts: print(v)

    print()
    print("Done. To dig deeper, run the single-CSV analysis on each side:")
    print(f"  python3 {sys.argv[0]} {baseline_csv}")
    print(f"  python3 {sys.argv[0]} {phasea_csv}")


# -----------------------------------------------------------------------------
# %% Cell 10 — Entry point
# -----------------------------------------------------------------------------

def cli():
    import argparse
    p = argparse.ArgumentParser(
        description="Analyze the per-gate lift of the Phase A / A.1 hardening.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:

  # Single-CSV: per-gate lift estimated from labels
  python3 %(prog)s 100-trades_labels.csv

  # Two-CSV: compare a pre-Phase-A baseline run against a post-Phase-A run
  python3 %(prog)s --baseline-csv pre.csv 100-trades_labels.csv

The two-CSV mode is the strongest validation: same trades labeled twice
(once on the baseline backtest, once on the Phase A backtest) lets you see
exactly which trades were removed and whether they were losers.
""",
    )
    p.add_argument("csv", nargs="?", default=DEFAULT_CSV,
                   help="Phase A (or single) labels CSV. Default: %(default)s")
    p.add_argument("--baseline-csv", metavar="PATH", default=None,
                   help="Optional pre-Phase-A baseline CSV. When given, runs comparison mode.")
    args = p.parse_args()

    if args.baseline_csv:
        base_path = Path(args.baseline_csv)
        a_path    = Path(args.csv)
        for label, p_ in [("baseline", base_path), ("phase A", a_path)]:
            if not p_.exists():
                print(f"ERROR: {label} CSV not found: {p_}", file=sys.stderr)
                sys.exit(1)
        print("=" * 72)
        print("COMPARISON MODE — pre-Phase-A vs post-Phase-A")
        print("=" * 72)
        run_comparison(base_path, a_path)
    else:
        main(Path(args.csv))


if __name__ == "__main__":
    cli()
